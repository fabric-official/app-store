/** AES-GCM helpers */
export async function importAesGcmKey(raw: ArrayBuffer): Promise<CryptoKey> {
  return crypto.subtle.importKey("raw", raw, { name:"AES-GCM" }, false, ["encrypt","decrypt"]);
}
export async function aesEncrypt(key: CryptoKey, plaintext: Uint8Array, aad?: Uint8Array) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = await crypto.subtle.encrypt({ name:"AES-GCM", iv, additionalData: aad }, key, plaintext);
  return { iv, ciphertext: new Uint8Array(enc) };
}
export async function aesDecrypt(key: CryptoKey, iv: Uint8Array, ciphertext: Uint8Array, aad?: Uint8Array) {
  const dec = await crypto.subtle.decrypt({ name:"AES-GCM", iv, additionalData: aad }, key, ciphertext);
  return new Uint8Array(dec);
}
