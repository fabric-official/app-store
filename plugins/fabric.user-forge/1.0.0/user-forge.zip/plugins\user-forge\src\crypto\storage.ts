/** Basic key/session storage (IndexedDB with localStorage fallback) */
const DB = "userforge";
const STORE = "kv";

function idb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => { req.result.createObjectStore(STORE); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function put(key: string, val: any) {
  try {
    const db = await idb();
    await new Promise((res, rej) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(val, key);
      tx.oncomplete = () => res(undefined);
      tx.onerror = () => rej(tx.error);
    });
  } catch {
    localStorage.setItem(`uf:${key}`, JSON.stringify(val));
  }
}

export async function get<T=any>(key: string): Promise<T | undefined> {
  try {
    const db = await idb();
    return await new Promise((res, rej) => {
      const tx = db.transaction(STORE, "readonly");
      const r = tx.objectStore(STORE).get(key);
      r.onsuccess = () => res(r.result as any);
      r.onerror = () => rej(r.error);
    });
  } catch {
    const raw = localStorage.getItem(`uf:${key}`);
    return raw ? JSON.parse(raw) : undefined;
  }
}
