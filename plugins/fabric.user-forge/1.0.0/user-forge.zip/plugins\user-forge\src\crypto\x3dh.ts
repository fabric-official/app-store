import { genECDH, ecdh, exportSpki, importSpki, b64, ub64 } from "./curve";
import { hkdf } from "./hkdf";

/** X3DH-style handshake (simplified, P-256) */
export type Bundle = { ik: string; spk: string; spkSig: string; opk?: string[] };
export type HandshakeOut = { rootKey: ArrayBuffer; ephPub: string };

async function sign(data: ArrayBuffer, priv: CryptoKey){
  const key = await crypto.subtle.importKey("pkcs8", await crypto.subtle.exportKey("pkcs8", priv), {name:"ECDSA", namedCurve:"P-256"}, false, ["sign"]);
  const sig = await crypto.subtle.sign({name:"ECDSA", hash:"SHA-256"}, key, data);
  return b64(sig);
}
async function verify(data: ArrayBuffer, sigB64: string, pub: CryptoKey){
  const key = await crypto.subtle.importKey("spki", await crypto.subtle.exportKey("spki", pub), {name:"ECDSA", namedCurve:"P-256"}, false, ["verify"]);
  return crypto.subtle.verify({name:"ECDSA", hash:"SHA-256"}, key, ub64(sigB64), data);
}

export async function makeBundle(identity: CryptoKey, signedPrekey: CryptoKey, oneTime?: CryptoKey[]): Promise<Bundle> {
  const ik = b64(await exportSpki(identity.publicKey));
  const spk = b64(await exportSpki(signedPrekey.publicKey));
  const spkSig = await sign(await exportSpki(signedPrekey.publicKey), identity.privateKey);
  const opk = oneTime?.slice(0,10).map(k => b64(await exportSpki(k.publicKey)));
  return { ik, spk, spkSig, opk };
}

export async function initiate(ourIK: CryptoKey, theirBundle: Bundle): Promise<HandshakeOut> {
  const eph = await genECDH();
  const theirIK = await importSpki(ub64(theirBundle.ik));
  const theirSPK = await importSpki(ub64(theirBundle.spk));
  // verify SPK signed by IK
  const ok = await verify(await exportSpki(theirSPK), theirBundle.spkSig, theirIK);
  if (!ok) throw new Error("SPK signature invalid");
  const dh1 = await ecdh(ourIK.privateKey, theirSPK);
  const dh2 = await ecdh(eph.privateKey, theirIK);
  const dh3 = await ecdh(eph.privateKey, theirSPK);
  const ikm = new Uint8Array([...new Uint8Array(dh1), ...new Uint8Array(dh2), ...new Uint8Array(dh3)]);
  const rootKey = await hkdf(ikm.buffer, new Uint8Array(32), new TextEncoder().encode("X3DH-RK"), 32);
  return { rootKey, ephPub: b64(await exportSpki(eph.publicKey)) };
}

export async function respond(ourIK: CryptoKey, ourSPK: CryptoKey, theirEphB64: string): Promise<ArrayBuffer> {
  const theirEph = await importSpki(ub64(theirEphB64));
  const dh1 = await ecdh(ourIK.privateKey, theirEph);
  const dh2 = await ecdh(ourSPK.privateKey, theirEph);
  const ikm = new Uint8Array([...new Uint8Array(dh1), ...new Uint8Array(dh2)]);
  const rootKey = await hkdf(ikm.buffer, new Uint8Array(32), new TextEncoder().encode("X3DH-RK"), 32);
  return rootKey;
}
