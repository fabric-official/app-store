import UFHome from "@/pages/UFHome";
import Messages from "@/pages/Messages";
import Bridges from "@/pages/Bridges";
import Devices from "@/pages/Devices";
import Contacts from "@/pages/Contacts";
import Email from "@/pages/Email";
import Meet from "@/pages/Meet";
import Settings from "@/pages/Settings";

export const routes = [
  { path: "/uf", element: <UFHome /> },
  { path: "/uf/messages", element: <Messages /> },
  { path: "/uf/bridges", element: <Bridges /> },
  { path: "/uf/devices", element: <Devices /> },
  { path: "/uf/contacts", element: <Contacts /> },
  { path: "/uf/email", element: <Email /> },
  { path: "/uf/meet", element: <Meet /> },
  { path: "/uf/settings", element: <Settings /> },
];
