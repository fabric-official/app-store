﻿import React from "react";
export default function PluginRoot() {
  return (
    <div style={{ padding: 16 }}>
      <h1>User Forge v1.0.0</h1>
      <p>Encrypted user communication client (chat/email/meet) for SuperNet.</p>
    </div>
  );
}
