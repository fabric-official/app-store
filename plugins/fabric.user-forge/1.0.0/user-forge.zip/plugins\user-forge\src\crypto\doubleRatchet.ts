import { hkdf } from "./hkdf";
import { importAesGcmKey, aesEncrypt, aesDecrypt } from "./aesgcm";
import { ecdh, genECDH, exportSpki, importSpki } from "./curve";

/** Double Ratchet (P-256 + HKDF + AES-GCM) */
export type Header = { dhPub: string; pn: number; n: number };
export type Ciphertext = { header: Header; ct: string; iv: string; aad?: string };

function concat(...arrs: Uint8Array[]) {
  let len = 0; for (const a of arrs) len += a.length;
  const out = new Uint8Array(len); let o=0;
  for (const a of arrs) { out.set(a, o); o += a.length; }
  return out;
}
function t(s: string) { return new TextEncoder().encode(s); }
function b64(ab: ArrayBuffer){ return btoa(String.fromCharCode(...new Uint8Array(ab))); }
function ub64(s: string){ const b=atob(s); const u=new Uint8Array(b.length); for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i); return u.buffer; }

async function kdfRoot(rootKey: ArrayBuffer, dhOut: ArrayBuffer){
  const salt = new Uint8Array(rootKey);
  const res = await hkdf(dhOut, salt, t("RK"), 64);
  return { rootKey: res.slice(0,32), cks: res.slice(32,48), ckr: res.slice(48,64) };
}
async function kdfChain(chainKey: ArrayBuffer){
  const res = await hkdf(chainKey, new Uint8Array(32), t("CK"), 64);
  return { chainKey: res.slice(0,32), msgKey: res.slice(32,64) };
}

export class RatchetSession {
  rootKey!: ArrayBuffer;
  dh!: CryptoKey;           // our current DH priv
  dhPub!: string;           // our current DH pub (spki b64)
  cks?: ArrayBuffer;        // sending chain key
  ckr?: ArrayBuffer;        // receiving chain key
  ns = 0;                   // message number in sending chain
  nr = 0;                   // message number in receiving chain
  pn = 0;                   // number of messages in previous sending chain
  skipped: Record<string, string> = {}; // map header key -> msgKey b64

  static async initAsInitiator(rootKey: ArrayBuffer, ourDH: CryptoKey, theirDHPubSpkiB64: string){
    const s = new RatchetSession();
    s.rootKey = rootKey;
    s.dh = ourDH;
    s.dhPub = b64(await exportSpki((await crypto.subtle.generateKey({name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).publicKey)); // keep pub ready
    // actually set to ourDH's pub:
    s.dhPub = b64(await exportSpki((await crypto.subtle.importKey("pkcs8", await crypto.subtle.exportKey("pkcs8", ourDH), {name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).publicKey).catch(()=>new ArrayBuffer(0)));
    const theirPub = await importSpki(ub64(theirDHPubSpkiB64));
    const dhOut = await ecdh(ourDH, theirPub);
    const { rootKey: rk, cks } = await kdfRoot(rootKey, dhOut);
    s.rootKey = rk; s.cks = cks; s.ns = 0; s.pn = 0;
    return s;
  }

  static async initAsResponder(rootKey: ArrayBuffer, ourDH: CryptoKey, theirDHPubSpkiB64: string){
    const s = new RatchetSession();
    s.rootKey = rootKey;
    s.dh = ourDH;
    s.dhPub = b64(await exportSpki((await crypto.subtle.generateKey({name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).publicKey)); // replaced
    s.dhPub = b64(await exportSpki((await crypto.subtle.importKey("pkcs8", await crypto.subtle.exportKey("pkcs8", ourDH), {name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).publicKey).catch(()=>new ArrayBuffer(0)));
    const theirPub = await importSpki(ub64(theirDHPubSpkiB64));
    const dhOut = await ecdh(ourDH, theirPub);
    const { rootKey: rk, ckr } = await kdfRoot(rootKey, dhOut);
    s.rootKey = rk; s.ckr = ckr; s.nr = 0;
    return s;
  }

  private headerKey(h: Header){ return `${h.dhPub}:${h.pn}:${h.n}`; }

  private async nextSending(){
    if (!this.cks) throw new Error("no sending chain");
    const { chainKey, msgKey } = await kdfChain(this.cks);
    this.cks = chainKey; this.ns += 1;
    return msgKey;
  }

  private async nextReceiving(){
    if (!this.ckr) throw new Error("no receiving chain");
    const { chainKey, msgKey } = await kdfChain(this.ckr);
    this.ckr = chainKey; this.nr += 1;
    return msgKey;
  }

  private async dhRatchet(theirPubB64: string){
    // set pn
    this.pn = this.ns; this.ns = 0;
    // replace our DH
    this.dh = (await crypto.subtle.generateKey({name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).privateKey;
    this.dhPub = b64(await exportSpki((await crypto.subtle.generateKey({name:"ECDH", namedCurve:"P-256"}, true, ["deriveBits"])).publicKey)); // replace with real
    // compute root/recv
    const theirPub = await importSpki(ub64(theirPubB64));
    const dhOut = await ecdh(this.dh, theirPub);
    const { rootKey: rk, ckr } = await kdfRoot(this.rootKey, dhOut);
    this.rootKey = rk; this.ckr = ckr; this.nr = 0;
    // then compute sending from our new DH with their pub
    const dhOut2 = await ecdh(this.dh, theirPub);
    const { rootKey: rk2, cks } = await kdfRoot(this.rootKey, dhOut2);
    this.rootKey = rk2; this.cks = cks;
  }

  async encrypt(plaintext: Uint8Array): Promise<Ciphertext> {
    const mk = await this.nextSending();
    const key = await importAesGcmKey(mk);
    const header: Header = { dhPub: this.dhPub, pn: this.pn, n: this.ns };
    const aad = t(JSON.stringify(header));
    const { iv, ciphertext } = await aesEncrypt(key, plaintext, aad);
    return { header, ct: b64(ciphertext), iv: b64(iv), aad: b64(aad.buffer) };
  }

  async decrypt(msg: Ciphertext): Promise<Uint8Array> {
    const tag = this.headerKey(msg.header);
    if (this.skipped[tag]) {
      const mkRaw = ub64(this.skipped[tag]); delete this.skipped[tag];
      const key = await importAesGcmKey(mkRaw);
      return aesDecrypt(key, new Uint8Array(ub64(msg.iv)), new Uint8Array(ub64(msg.ct)), new Uint8Array(ub64(msg.aad || "")));
    }
    if (!this.ckr || msg.header.dhPub !== this.dhPub) {
      await this.dhRatchet(msg.header.dhPub);
    }
    // advance until n
    while (this.nr < msg.header.n) {
      const mk = await this.nextReceiving();
      this.skipped[`${msg.header.dhPub}:${this.pn}:${this.nr}`] = b64(mk);
    }
    const mk = await this.nextReceiving();
    const key = await importAesGcmKey(mk);
    return aesDecrypt(key, new Uint8Array(ub64(msg.iv)), new Uint8Array(ub64(msg.ct)), new Uint8Array(ub64(msg.aad || "")));
  }
}
