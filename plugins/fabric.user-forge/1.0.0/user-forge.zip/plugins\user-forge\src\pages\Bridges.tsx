import { useEffect, useState } from "react";
import { listBridges } from "@/api/supernet";
import { Card, Badge } from "@/components/ui";

export default function Bridges(){
  const [bridges, setBridges] = useState<any[]>([]);
  useEffect(()=>{ (async()=> setBridges(await listBridges()))(); },[]);
  return (
    <div className="p-4 grid md:grid-cols-2 gap-4">
      {bridges.map(b => (
        <Card key={b.id}>
          <div className="flex items-center justify-between">
            <div className="font-bold">{b.label || b.id}</div>
            <Badge>{b.online ? "online" : "offline"}</Badge>
          </div>
          <div className="text-sm opacity-70">kind: {b.kind}</div>
          <div className="text-sm opacity-70">latency: {b.metrics?.latencyMs ?? "?"} ms</div>
          <div className="text-sm opacity-70">bandwidth: {b.metrics?.bandwidthKbps ?? "?"} kbps</div>
        </Card>
      ))}
    </div>
  );
}
