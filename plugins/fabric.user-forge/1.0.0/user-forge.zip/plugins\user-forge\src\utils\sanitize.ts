/** Hardened HTML sanitizer (minimal). Replace with DOMPurify server-side if available. */
export function sanitize(html: string): string {
  return html
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
    .replace(/ on[a-z]+="[^"]*"/gi, "")
    .replace(/javascript:/gi, "");
}
