import crypto from "crypto";
import fs from "fs";
import path from "path";
import fetch from "node-fetch";

function toBytes(b64: string){ return Buffer.from(b64, "base64"); }

export async function verifyDetachedEd25519({ publicKeyPem, data, signatureB64 }: { publicKeyPem: string; data: Buffer; signatureB64: string }): Promise<boolean> {
  const key = crypto.createPublicKey(publicKeyPem);
  return crypto.verify(null, data, key, Buffer.from(signatureB64, "base64"));
}

export async function fetchText(url: string): Promise<string> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch failed ${res.status}`);
  return res.text();
}
export async function fetchJSON<T=any>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch failed ${res.status}`);
  return res.json() as Promise<T>;
}
