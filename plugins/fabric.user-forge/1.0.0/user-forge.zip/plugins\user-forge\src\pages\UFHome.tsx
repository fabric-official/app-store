export default function UFHome(){
  return (
    <div className="p-6 space-y-2">
      <h1 className="text-xl font-bold">User Forge</h1>
      <p>Secure end-to-end communications across SuperNet bridges.</p>
    </div>
  );
}
