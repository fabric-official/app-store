export function Button(props: any){ return <button {...props} className={"px-3 py-2 rounded border " + (props.className||"")}>{props.children}</button>; }
export function Input(props: any){ return <input {...props} className={"px-3 py-2 rounded border w-full " + (props.className||"")}/>; }
export function Card({children}: any){ return <div className="border rounded p-3">{children}</div>; }
export function Badge({children}: any){ return <span className="px-2 py-1 text-xs border rounded">{children}</span>; }
export function Alert({children}: any){ return <div className="border-l-4 border-red-500 bg-red-50 p-3">{children}</div>; }
