import { Card } from "@/components/ui";

export default function Settings(){
  return (
    <div className="p-4">
      <Card>
        <div className="font-bold">Settings</div>
        <div className="text-sm opacity-70">Identity, keys, backup, bridges configuration live here.</div>
      </Card>
    </div>
  );
}
