import { useEffect, useState } from "react";
import { listDevices } from "@/api/supernet";
import { Card } from "@/components/ui";

export default function Devices(){
  const [devices, setDevices] = useState<any[]>([]);
  useEffect(()=>{ (async()=> setDevices(await listDevices()))(); },[]);
  return (
    <div className="p-4 grid md:grid-cols-2 gap-4">
      {devices.map(d => (
        <Card key={d.id}>
          <div className="font-bold">{d.label || d.id}</div>
          <div className="text-sm opacity-70">last seen: {d.lastSeen}</div>
          <div className="text-sm opacity-70">bridges: {d.bridges?.join(", ")}</div>
        </Card>
      ))}
    </div>
  );
}
