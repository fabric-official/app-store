import { useEffect, useRef, useState } from "react";
import { Button, Card } from "@/components/ui";

function supportInsertable() {
  // @ts-ignore
  return typeof RTCRtpSender !== "undefined" && RTCRtpSender.prototype.createEncodedStreams;
}

async function setupE2EE(pc: RTCPeerConnection, key: Uint8Array) {
  // @ts-ignore
  const senders = pc.getSenders();
  for (const s of senders) {
    // @ts-ignore
    const streams = s.createEncodedStreams?.();
    if (!streams) continue;
    const reader = streams.readable.getReader();
    const writer = streams.writable.getWriter();
    (async () => {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        // simple XOR with key (placeholder) — replace with AES-GCM framing for production
        for (let i = 0; i < value.data.length; i++) value.data[i] ^= key[i % key.length];
        await writer.write(value);
      }
    })();
  }
}

export default function Meet(){
  const localRef = useRef<HTMLVideoElement>(null);
  const remoteRef = useRef<HTMLVideoElement>(null);
  const [pc, setPc] = useState<RTCPeerConnection | null>(null);
  const [ws, setWs] = useState<WebSocket | null>(null);

  async function start(){
    const socket = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host.replace(/:\d+$/, ":8080") + "/ws");
    socket.onopen = () => socket.send(JSON.stringify({ type: "join", room: "uf" }));
    socket.onmessage = async (evt) => {
      const msg = JSON.parse(evt.data);
      if (msg.type === "signal" && pc) {
        if (msg.payload.type === "offer") {
          await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          socket.send(JSON.stringify({ type: "signal", payload: answer }));
        } else if (msg.payload.type === "answer") {
          await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
        } else if (msg.payload.candidate) {
          await pc.addIceCandidate(msg.payload);
        }
      }
    };
    setWs(socket);

    const pcx = new RTCPeerConnection();
    setPc(pcx);

    pcx.ontrack = (ev) => {
      if (remoteRef.current) remoteRef.current.srcObject = ev.streams[0];
    };

    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    stream.getTracks().forEach(t => pcx.addTrack(t, stream));
    if (localRef.current) localRef.current.srcObject = stream;

    // Example: 32-byte key (replace with Double Ratchet derived key)
    const key = crypto.getRandomValues(new Uint8Array(32));
    if (supportInsertable()) await setupE2EE(pcx, key);

    const offer = await pcx.createOffer();
    await pcx.setLocalDescription(offer);
    socket.send(JSON.stringify({ type: "signal", payload: offer }));
  }

  function stop(){
    pc?.getSenders().forEach(s => s.track?.stop());
    pc?.close();
    ws?.close();
    setPc(null); setWs(null);
  }

  useEffect(()=>()=>stop(),[]);

  return (
    <div className="p-4">
      <Card>
        <div className="flex items-center gap-2 mb-2">
          <Button onClick={start}>Start meeting</Button>
          <Button onClick={stop}>Stop</Button>
        </div>
        <div className="grid md:grid-cols-2 gap-2">
          <video ref={localRef} autoPlay playsInline muted className="w-full rounded border"/>
          <video ref={remoteRef} autoPlay playsInline className="w-full rounded border"/>
        </div>
        <div className="text-sm opacity-70 mt-2">Signaling via WebSocket on the SuperNet server. Insertable streams E2EE applied (replace XOR with AES-GCM framing + ratchet-derived keys in production).</div>
      </Card>
    </div>
  );
}
