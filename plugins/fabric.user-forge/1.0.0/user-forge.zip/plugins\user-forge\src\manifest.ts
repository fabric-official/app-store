export const manifest = {
  id: "fabric.user-forge",
  name: "User Forge",
  version: "1.0.0",
  author: "Atomic Limited",
  description: "End-user communications forge for SuperNet — chat, email, meetings across heterogeneous bridges (DTN, LoRa, BLE, Satellite, IP).",
  routes: ["/uf", "/uf/messages", "/uf/bridges", "/uf/devices", "/uf/contacts", "/uf/email", "/uf/meet", "/uf/settings"],
  permissions: [
    "messaging:send","messaging:receive",
    "contacts:read","contacts:write",
    "devices:link","devices:list",
    "bridges:discover","bridges:configure",
    "crypto:use","files:read","files:write","camera:use","microphone:use"
  ]
};
