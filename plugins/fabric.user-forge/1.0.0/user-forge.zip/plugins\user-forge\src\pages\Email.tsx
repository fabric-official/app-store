import { useState } from "react";
import { Input, Button, Card } from "@/components/ui";
import { sendMessage } from "@/api/supernet";

export default function Email(){
  const [to, setTo] = useState("");
  const [subj, setSubj] = useState("");
  const [body, setBody] = useState("");

  async function send(){
    await sendMessage({ to, kind:"email", body: JSON.stringify({ subject: subj, body }), require:{ e2e: true } });
    setTo(""); setSubj(""); setBody("");
    alert("Email enqueued securely");
  }

  return (
    <div className="p-4">
      <Card>
        <div className="space-y-2">
          <Input placeholder="To (contact id or address)" value={to} onChange={e=>setTo(e.target.value)}/>
          <Input placeholder="Subject" value={subj} onChange={e=>setSubj(e.target.value)}/>
          <textarea className="w-full border rounded p-2" rows={8} placeholder="Body" value={body} onChange={e=>setBody(e.target.value)} />
          <Button onClick={send}>Send secure email</Button>
        </div>
      </Card>
    </div>
  );
}
