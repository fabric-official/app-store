/** HKDF-SHA256 using WebCrypto */
export async function hkdf(ikm: ArrayBuffer, salt: ArrayBuffer, info: Uint8Array, length=32): Promise<ArrayBuffer> {
  const baseKey = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name:"HKDF", hash:"SHA-256", salt, info }, baseKey, length*8);
  return bits;
}
