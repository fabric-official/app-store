/** SuperNet API adapter for User Forge */
const E = (import.meta as any).env || {};
const API = (E.VITE_SUPERNET_API as string | undefined)?.replace(/\/+$/,'') || "http://localhost:8080";

export type BridgeKind = "ip" | "sms" | "ble" | "wifi-direct" | "lora" | "hf" | "satellite" | "acoustic" | "sneakernet" | "dtn";
export type MessageKind = "text" | "file" | "email" | "voice" | "video" | "meeting" | "control";

export type Bridge = { id: string; kind: BridgeKind; label?: string; online: boolean; metrics?: { latencyMs?: number; bandwidthKbps?: number; reliability?: number; cost?: number; battery?: number }; capabilities?: string[]; };
export type Device = { id: string; label?: string; lastSeen?: string; bridges: BridgeKind[] };
export type Contact = { id: string; display: string; pubkey?: string; devices?: string[] };

export type Outbound = { to: string; kind: MessageKind; body?: string; fileId?: string; meta?: Record<string, any>; priority?: "realtime" | "interactive" | "bulk" | "background"; require?: { online?: boolean; acks?: number; e2e?: boolean }; };

function j(url: string) { return `${API}${url}`; }

export async function listBridges(): Promise<Bridge[]> { const r = await fetch(j("/api/bridges/list")); if (!r.ok) return []; return r.json(); }
export async function advertiseBridge(payload: Partial<Bridge>) { const r = await fetch(j("/api/bridges/advertise"), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }); return r.ok; }
export async function listDevices(): Promise<Device[]> { const r = await fetch(j("/api/devices/list")); if (!r.ok) return []; return r.json(); }
export async function listContacts(): Promise<Contact[]> { const r = await fetch(j("/api/contacts/list")); if (!r.ok) return []; return r.json(); }
export async function upsertContact(c: Contact) { const r = await fetch(j("/api/contacts/upsert"), { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(c) }); return r.ok; }

export async function sendMessage(msg: Outbound) { const r = await fetch(j("/api/messaging/send"), { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(msg) }); if (!r.ok) throw new Error(`send failed ${r.status}`); return r.json().catch(()=>({ ok:true })); }
export async function getThread(contactId: string) { const r = await fetch(j(`/api/messaging/thread?to=${encodeURIComponent(contactId)}`)); if (!r.ok) return []; return r.json(); }
export async function dtnEnqueue(msg: Outbound) { const r = await fetch(j("/api/dtn/enqueue"), { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(msg) }); return r.ok; }
export async function dtnFlush() { const r = await fetch(j("/api/dtn/flush"), { method: "POST" }); return r.ok; }

export async function cryptoEnvelope(toContactId: string, payload: any) { const r = await fetch(j("/api/crypto/envelope"), { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ to: toContactId, payload }) }); if (!r.ok) throw new Error("crypto envelope failed"); return r.json(); }
