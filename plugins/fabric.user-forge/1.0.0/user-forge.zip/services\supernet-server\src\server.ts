import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import multer from "multer";
import { read, write } from "./store.js";
import { fetchJSON, verifyDetachedEd25519 } from "./crypto.js";
import http from "http";
import { WebSocketServer } from "ws";

const app = express();
app.use(express.json({ limit: "10mb" }));
app.use(cors());

// --- WebSocket for signaling (meet) ---
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });
type Peer = { id: string; ws: any; room?: string };
const peers = new Map<string, Peer>();

function broadcast(room: string, sender: string, data: any){
  for (const [id, peer] of peers) {
    if (peer.room === room && id !== sender) {
      try { peer.ws.send(JSON.stringify(data)); } catch {}
    }
  }
}

wss.on("connection", (ws) => {
  let pid = Math.random().toString(36).slice(2);
  peers.set(pid, { id: pid, ws });
  ws.on("message", (raw: Buffer) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === "join") {
        peers.get(pid)!.room = msg.room || "default";
        ws.send(JSON.stringify({ type: "joined", id: pid }));
      } else if (msg.type === "signal") {
        const room = peers.get(pid)!.room || "default";
        broadcast(room, pid, { type: "signal", from: pid, payload: msg.payload });
      }
    } catch {}
  });
  ws.on("close", () => peers.delete(pid));
});

// --- Contacts ---
app.get("/api/contacts/list", (req, res) => {
  res.json(read().contacts);
});
app.post("/api/contacts/upsert", (req, res) => {
  const db = read();
  const c = req.body;
  const i = db.contacts.findIndex(x => x.id === c.id);
  if (i === -1) db.contacts.push(c);
  else db.contacts[i] = { ...db.contacts[i], ...c };
  write(db);
  res.json({ ok: true });
});

// --- Devices ---
app.get("/api/devices/list", (req, res) => {
  res.json(read().devices);
});

// --- Bridges ---
app.get("/api/bridges/list", (req, res) => {
  res.json(read().bridges);
});
app.post("/api/bridges/advertise", (req, res) => {
  const db = read();
  const b = req.body;
  const i = db.bridges.findIndex(x => x.id === b.id);
  if (i === -1) db.bridges.push(b);
  else db.bridges[i] = { ...db.bridges[i], ...b };
  write(db);
  res.json({ ok: true });
});

// --- Messaging ---
app.get("/api/messaging/thread", (req, res) => {
  const to = String(req.query.to || "");
  const db = read();
  res.json(db.threads[to] || []);
});

app.post("/api/messaging/send", (req, res) => {
  const { to, kind, body } = req.body || {};
  if (!to || !kind) return res.status(400).json({ error: "to/kind required" });
  const db = read();
  db.threads[to] = db.threads[to] || [];
  db.threads[to].push({ dir: "in", body: body || "", at: new Date().toISOString() });
  write(db);
  res.json({ ok: true });
});

// --- DTN ---
app.post("/api/dtn/enqueue", (req, res) => {
  const { to, payload } = req.body || {};
  const db = read();
  const id = Math.random().toString(36).slice(2);
  db.dtn.push({ id, to, payload, at: new Date().toISOString() });
  write(db);
  res.json({ ok: true, id });
});
app.post("/api/dtn/flush", (req, res) => {
  const db = read();
  for (const b of db.dtn) {
    db.threads[b.to] = db.threads[b.to] || [];
    db.threads[b.to].push({ dir: "in", body: JSON.stringify(b.payload), at: new Date().toISOString() });
  }
  db.dtn = [];
  write(db);
  res.json({ ok: true });
});

// --- Plugins (minimal) ---
app.get("/api/plugins/list", (req, res) => {
  // list installed plugin IDs from filesystem
  const dir = path.join(process.cwd(), "plugins");
  let items: string[] = [];
  try {
    items = fs.readdirSync(dir).filter(x => fs.statSync(path.join(dir, x)).isDirectory());
  } catch {}
  res.json({ plugins: items });
});

app.post("/api/plugins/install", async (req, res) => {
  // WARNING: This is a minimal example. Real system should validate archives, checksums, and sandbox execution.
  const { id, version, source, verifySignature } = req.body || {};
  if (!id || !source) return res.status(400).json({ error: "id/source required" });
  // Signature verification (ed25519, detached, optional)
  if (verifySignature && process.env.PLUGIN_PUBKEY_PEM && process.env.PLUGIN_REGISTRY_JSON && process.env.PLUGIN_REGISTRY_SIG_B64) {
    try {
      const text = await (await import("node-fetch")).default(process.env.PLUGIN_REGISTRY_JSON).then(r=>r.text());
      const ok = await verifyDetachedEd25519({ publicKeyPem: process.env.PLUGIN_PUBKEY_PEM, data: Buffer.from(text, "utf8"), signatureB64: process.env.PLUGIN_REGISTRY_SIG_B64 });
      if (!ok) return res.status(400).json({ error: "registry signature invalid" });
    } catch (e: any) {
      return res.status(500).json({ error: "signature check failed", detail: String(e?.message||e) });
    }
  }
  const dir = path.join(process.cwd(), "plugins", id);
  fs.mkdirSync(dir, { recursive: true });
  // naive install marker
  fs.writeFileSync(path.join(dir, "installed.json"), JSON.stringify({ id, version, source, at: new Date().toISOString() }, null, 2));
  res.json({ ok: true, id });
});

// CSP headers (example)
app.use((_, res, next) => {
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; img-src 'self' data: https://raw.githubusercontent.com https://cdn.jsdelivr.net; " +
    "style-src 'self' 'unsafe-inline'; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
  next();
});

const PORT = Number(process.env.PORT || 8080);
server.listen(PORT, () => {
  console.log("[supernet-server] listening on", PORT);
});
