/** ECDH P-256 utilities using WebCrypto SubtleCrypto */
export type KeyPair = { publicKey: CryptoKey; privateKey: CryptoKey };
export async function genECDH(): Promise<KeyPair> {
  return crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits", "deriveKey"]) as Promise<any>;
}
export async function exportSpki(key: CryptoKey): Promise<ArrayBuffer> {
  return crypto.subtle.exportKey("spki", key);
}
export async function exportPkcs8(key: CryptoKey): Promise<ArrayBuffer> {
  return crypto.subtle.exportKey("pkcs8", key);
}
export async function importSpki(spki: ArrayBuffer): Promise<CryptoKey> {
  return crypto.subtle.importKey("spki", spki, { name: "ECDH", namedCurve: "P-256" }, true, []);
}
export async function importPkcs8(pkcs8: ArrayBuffer): Promise<CryptoKey> {
  return crypto.subtle.importKey("pkcs8", pkcs8, { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits", "deriveKey"]);
}
export async function ecdh(privateKey: CryptoKey, publicKey: CryptoKey): Promise<ArrayBuffer> {
  return crypto.subtle.deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256);
}
export function b64(ab: ArrayBuffer): string { return btoa(String.fromCharCode(...new Uint8Array(ab))); }
export function ub64(s: string): ArrayBuffer { const b = atob(s); const u = new Uint8Array(b.length); for (let i=0;i<b.length;i++) u[i]=b.charCodeAt(i); return u.buffer; }
