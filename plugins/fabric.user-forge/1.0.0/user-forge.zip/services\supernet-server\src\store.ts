import fs from "fs";
import path from "path";

export const DATA_DIR = path.resolve(process.env.SUPERNET_DATA || path.join(process.cwd(), "data"));
const FILE = path.join(DATA_DIR, "db.json");

type DB = {
  contacts: Array<{ id: string; display: string; pubkey?: string; devices?: string[] }>;
  devices: Array<{ id: string; label?: string; lastSeen?: string; bridges: string[] }>;
  threads: Record<string, Array<{ dir: "in" | "out"; body: string; at: string }>>;
  bridges: Array<{ id: string; kind: string; label?: string; online: boolean; metrics?: any; capabilities?: string[] }>;
  dtn: Array<{ id: string; to: string; payload: any; at: string }>;
};

function ensure(){
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) {
    const seed: DB = { contacts: [], devices: [], threads: {}, bridges: [], dtn: [] };
    fs.writeFileSync(FILE, JSON.stringify(seed, null, 2), "utf8");
  }
}
export function read(): DB { ensure(); return JSON.parse(fs.readFileSync(FILE, "utf8")); }
export function write(db: DB){ ensure(); fs.writeFileSync(FILE, JSON.stringify(db, null, 2), "utf8"); }
