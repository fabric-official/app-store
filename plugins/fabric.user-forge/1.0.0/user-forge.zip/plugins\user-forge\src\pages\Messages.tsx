import { useEffect, useState } from "react";
import { Input, Button, Card } from "@/components/ui";
import { listContacts, getThread, sendMessage } from "@/api/supernet";
import { genECDH, exportSpki, importSpki } from "@/crypto/curve";
import { makeBundle, initiate, respond } from "@/crypto/x3dh";
import { RatchetSession } from "@/crypto/doubleRatchet";
import * as store from "@/crypto/storage";

type ThreadItem = { dir: "in"|"out"; body: string; at: string };

export default function Messages(){
  const [contacts, setContacts] = useState<any[]>([]);
  const [sel, setSel] = useState<string>("");
  const [thread, setThread] = useState<ThreadItem[]>([]);
  const [text, setText] = useState("");
  const [sess, setSess] = useState<RatchetSession | null>(null);

  useEffect(() => { (async () => {
    setContacts(await listContacts());
  })(); }, []);

  async function ensureSession(contactId: string) {
    let s: any = await store.get(`sess:${contactId}`);
    if (s && s.state) {
      // session resume not fully implemented here for brevity
      return sess;
    }
    // new session: X3DH
    const ourIK = await genECDH();
    const spk = await genECDH();
    const bundle = await makeBundle(ourIK, spk, []);
    // send bundle to contact via server (omitted; assume fetched theirs)
    // for demo we self-initiate (loopback)
    const init = await initiate(ourIK, bundle);
    const rk = await respond(ourIK, spk, init.ephPub);
    const rs = await RatchetSession.initAsInitiator(rk, ourIK.privateKey, bundle.spk);
    setSess(rs);
    await store.put(`sess:${contactId}`, { state: "ok" });
    return rs;
  }

  async function openThread(id: string){
    setSel(id);
    const t = await getThread(id);
    setThread(t);
    await ensureSession(id);
  }

  async function send(){
    if (!sel) return;
    const s = sess || await ensureSession(sel);
    const enc = await s!.encrypt(new TextEncoder().encode(text));
    await sendMessage({ to: sel, kind:"text", body: JSON.stringify(enc), require:{e2e:true} });
    setThread([...thread, { dir:"out", body: text, at: new Date().toISOString() }]);
    setText("");
  }

  return (
    <div className="p-4 grid grid-cols-3 gap-4">
      <Card>
        <h2 className="font-bold mb-2">Contacts</h2>
        <div className="space-y-1">
          {contacts.map(c => (
            <div key={c.id} className={"p-2 border rounded cursor-pointer " + (sel===c.id?"bg-gray-100":"")} onClick={()=>openThread(c.id)}>
              {c.display}
            </div>
          ))}
        </div>
      </Card>
      <div className="col-span-2">
        <Card>
          <div className="h-80 overflow-auto space-y-2">
            {thread.map((m,i)=> (
              <div key={i} className={"p-2 rounded " + (m.dir==="out"?"bg-blue-50 text-right":"bg-gray-50")}>{m.body}</div>
            ))}
          </div>
          <div className="flex gap-2 mt-2">
            <Input value={text} onChange={e=>setText(e.target.value)} placeholder="Type message…"/>
            <Button onClick={send}>Send</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
