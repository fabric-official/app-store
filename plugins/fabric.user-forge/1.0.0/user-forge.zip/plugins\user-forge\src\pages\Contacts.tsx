import { useEffect, useState } from "react";
import { listContacts, upsertContact } from "@/api/supernet";
import { Input, Button, Card } from "@/components/ui";

export default function Contacts(){
  const [contacts, setContacts] = useState<any[]>([]);
  const [display, setDisplay] = useState("");
  useEffect(()=>{ (async()=> setContacts(await listContacts()))(); },[]);

  async function add(){
    const id = display.toLowerCase().replace(/\s+/g,"-");
    await upsertContact({ id, display });
    setContacts(await listContacts());
    setDisplay("");
  }
  return (
    <div className="p-4 space-y-4">
      <Card>
        <div className="flex gap-2">
          <Input value={display} onChange={e=>setDisplay(e.target.value)} placeholder="New contact display name"/>
          <Button onClick={add}>Add</Button>
        </div>
      </Card>
      <div className="grid md:grid-cols-2 gap-4">
        {contacts.map(c => (
          <Card key={c.id}>
            <div className="font-bold">{c.display}</div>
            <div className="text-sm opacity-70">{c.id}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
