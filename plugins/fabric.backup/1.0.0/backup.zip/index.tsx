import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Encrypted Backup v1.0.0</h1><p>AES-GCM encrypted backup/restore for state and DTN queue.</p></div>);
}