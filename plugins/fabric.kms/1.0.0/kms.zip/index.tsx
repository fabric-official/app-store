import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>KMS & Attestation v1.0.0</h1><p>Cosign public key distribution, rotation, attestation policy & verify helpers.</p></div>);
}