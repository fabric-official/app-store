import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Policy & Permissions v1.0.0</h1><p>Capability policy editor and enforcement hooks for plugin manifests.</p></div>);
}