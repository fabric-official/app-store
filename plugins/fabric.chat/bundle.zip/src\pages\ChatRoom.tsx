import React, { useEffect, useRef, useState } from 'react';
import { api } from '../api';

export default function ChatRoom() {
  const [roomId, setRoomId] = useState<string>('');
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState('');
  const wsRef = useRef<WebSocket|null>(null);

  async function createRoom() {
    const r = await api('/chat/rooms', { method: 'POST', body: JSON.stringify({ scope: 'group', kind: 'group', title: 'General' }) });
    setRoomId(r.id);
    await load(r.id);
    connectWS(r.id);
  }

  async function load(id: string) {
    const r = await api(`/chat/rooms/${id}/messages`);
    setMessages(r.messages);
  }

  function connectWS(id: string) {
    const base = (window as any).__FABRIC_WS__ || `ws://${location.host}`;
    const ws = new WebSocket(base + `/ws/chat/${id}`);
    wsRef.current = ws;
    ws.onmessage = (ev) => {
      try { const msg = JSON.parse(ev.data); setMessages((m) => [...m, msg]); } catch {}
    };
    ws.onclose = () => { setTimeout(()=>connectWS(id), 1000); };
  }

  async function send() {
    if (!roomId) return;
    await api(`/chat/rooms/${roomId}/messages`, { method: 'POST', body: JSON.stringify({ content_md: text }) });
    setText('');
    await load(roomId);
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Chat</h1>
      {!roomId && <button className="px-3 py-2 rounded bg-black text-white" onClick={createRoom}>Create Room</button>}
      {roomId && (
        <div className="border rounded-2xl p-4">
          <div className="h-80 overflow-y-auto space-y-2 mb-3">
            {messages.map((m, i) => (<div key={i} className="text-sm"><span className="font-semibold">{m.author_id?.slice(0,6)}</span>: {m.content_md}</div>))}
          </div>
          <div className="flex gap-2">
            <input className="border rounded px-3 py-2 flex-1" placeholder="Type..." value={text} onChange={e=>setText(e.target.value)} />
            <button className="px-3 py-2 rounded bg-black text-white" onClick={send}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
}
