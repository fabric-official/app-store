export async function api(path: string, opts: RequestInit = {}) {
  const base = (window as any).__FABRIC_API__ || '/api';
  const res = await fetch(base + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}
