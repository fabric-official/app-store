import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Auto Updater v1.0.0</h1><p>Background updater with cosign verify and staged rollout.</p></div>);
}