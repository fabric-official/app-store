import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>DTN Core v1.0.0</h1><p>Delay/Disruption-Tolerant Networking core with encrypted bundle queue and opportunistic forwarding.</p></div>);
}