import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Signed Audit Log v1.0.0</h1><p>Ed25519-signed audit logs for install/update/policy changes.</p></div>);
}