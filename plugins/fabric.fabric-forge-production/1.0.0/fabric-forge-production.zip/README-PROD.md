# Fabric Forge — Production Pack

## One-command apply
```powershell
# from your forge project root
node ./scripts/apply-pack.mjs .
# (or) PowerShell route injection only:
./scripts/apply-route.ps1 -ProjectRoot .
```

Then:
```bash
cp .env.example .env.local
# ensure values are correct, then
npm i
npm run dev    # open /agents
```

## What this pack includes
- Hardened App Store client (branch-aware, timeout, fallback)
- Agents page with pagination & Install/Disable/Uninstall
- Agent card with safety and license display
- MarkdownRenderer with sanitizer hook
- Route/alias auto-patcher scripts
- CSP/CORS guidance

## SuperNet endpoints expected
- `POST /api/plugins/install`
- `GET  /api/plugins/list`
- Optional: `POST /api/plugins/disable`, `POST /api/plugins/uninstall`, `GET /api/plugins/status?id=`
