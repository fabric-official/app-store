\
Param(
  [string]$ProjectRoot = "."
)

$ErrorActionPreference = "Stop"
$routes = Join-Path $ProjectRoot "src\routes.ts"
if (!(Test-Path $routes)) {
  Write-Host "[WARN] routes.ts not found at $routes — skipping" -ForegroundColor Yellow
  exit 0
}

$content = Get-Content $routes -Raw
if ($content -notmatch "/agents") {
  if ($content -notmatch "import\s+AgentsPage\s+from\s+\"@/pages/Agents\"") {
    $content = "import AgentsPage from ""@/pages/Agents""`r`n" + $content
  }
  $content = $content + "`r`n// injected by Forge Prod Pack`r`n(routes as any).push?.({ path: ""/agents"", element: <AgentsPage /> });`r`n"
  Set-Content $routes $content -Encoding UTF8
  Write-Host "[OK] Injected /agents route" -ForegroundColor Green
} else {
  Write-Host "[OK] /agents route already present" -ForegroundColor Green
}
