import { sanitize } from "@/utils/sanitize";
export function MarkdownRenderer({ html }: { html: string }) {
  const safe = typeof sanitize === "function" ? sanitize(html) : html;
  return <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: safe }} />;
}
