import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function AgentCard({
  plugin, installed, onInstall, onDisable, onUninstall
}: {
  plugin: { id: string; name: string; version: string; summary?: string; icon?: string; author?: string; license?: string; verified?: boolean; README?: string; };
  installed?: boolean;
  onInstall?: () => void;
  onDisable?: () => void;
  onUninstall?: () => void;
}) {
  return (
    <Card className="flex flex-col">
      <CardHeader className="space-y-2">
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-base flex items-center gap-2">
            {plugin.icon && <img src={plugin.icon} alt="" className="w-6 h-6 rounded" referrerPolicy="no-referrer" />}
            {plugin.name}
          </CardTitle>
          <div className="flex items-center gap-2">
            {plugin.verified && <Badge variant="secondary" title="Signature present">Verified</Badge>}
            <Badge variant="outline">v{plugin.version}</Badge>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs opacity-70">
          {plugin.author && <span>by {plugin.author}</span>}
          {plugin.license && <span>• {plugin.license}</span>}
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-3">
        <p className="text-sm opacity-80 line-clamp-3">{plugin.summary || "No summary provided."}</p>
        <div className="mt-auto flex items-center gap-2">
          {installed ? (<>
              {onDisable && <Button variant="outline" onClick={onDisable}>Disable</Button>}
              {onUninstall && <Button variant="destructive" onClick={onUninstall}>Uninstall</Button>}
            </>)
            : (<Button onClick={onInstall}>Install</Button>)}
          {plugin.README && (
            <a className="text-sm underline opacity-80 hover:opacity-100" href={plugin.README} target="_blank" rel="noreferrer noopener">
              README
            </a>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
