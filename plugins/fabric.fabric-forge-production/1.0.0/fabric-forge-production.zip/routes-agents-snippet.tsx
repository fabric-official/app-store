// Add this to src/routes.ts
// import AgentsPage from "@/pages/Agents";
// routes.push({ path: "/agents", element: <AgentsPage /> });