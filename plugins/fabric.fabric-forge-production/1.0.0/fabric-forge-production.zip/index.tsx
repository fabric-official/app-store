﻿import React from "react";
export default function PluginRoot() {
  return (
    <div style={{ padding: 16 }}>
      <h1>Fabric Forge Production v1.0.0</h1>
      <p>Production-grade Fabric Forge shell plugin.</p>
    </div>
  );
}
