/**
 * Forge App Store client — production-hardened
 * Repo/branch aware, RAW→CDN fallback, timeout+retry, install/disable/uninstall hooks.
 */
export type ForgePlugin = {
  id: string; name: string; version: string;
  summary?: string; author?: string; license?: string; homepage?: string;
  verified?: boolean; icon?: string; README?: string; packageUrl?: string;
  categories?: string[]; installs?: number;
};

type RegistryIndex = { updated_at?: string; plugins: any[] };

const E = (import.meta as any).env || {};
const APP_STORE_BASE = E.VITE_APP_STORE_BASE as string | undefined;
const APP_STORE_REPO = E.VITE_APP_STORE_REPO as string | undefined;
const APP_STORE_REF  = E.VITE_APP_STORE_REF as string | undefined;
const SUPERNET_API   = E.VITE_SUPERNET_API as string | undefined;

function reqEnv(name: string, val: string | undefined) { if (!val) throw new Error(`Missing env ${name}`); return val; }
function parseRepoInput(repo?: string, ref?: string){ if(!repo) return {org:undefined,repo:undefined,ref};
  const a=/^https?:\/\/github\.com\/([^\/]+)\/([^\/]+)\/tree\/([^\/#?]+).*$/i.exec(repo);
  if(a) return {org:a[1],repo:a[2],ref:a[3]};
  const b=/^([^\/]+)\/([^#]+)(?:#(.+))?$/.exec(repo);
  if(b) return {org:b[1],repo:b[2],ref:ref||b[3]};
  return {org:undefined,repo:undefined,ref}; }
function buildBases(){ if(APP_STORE_BASE) return [APP_STORE_BASE.replace(/\/+$/,'')];
  const {org,repo,ref}=parseRepoInput(APP_STORE_REPO,APP_STORE_REF);
  if(org&&repo&&ref){ return [
    `https://raw.githubusercontent.com/${org}/${repo}/${ref}`,
    `https://cdn.jsdelivr.net/gh/${org}/${repo}@${ref}`
  ]; }
  throw new Error("Set VITE_APP_STORE_BASE or VITE_APP_STORE_REPO(+VITE_APP_STORE_REF)."); }
function joinUrl(b:string,p:string){return `${b.replace(/\/+$/,'')}/${p.replace(/^\/+/, '')}`}
function s(x:any){return typeof x==='string'?x:undefined}
function coerce(p:any,base:string){
  const id=s(p?.id), name=s(p?.name), version=s(p?.version); if(!id||!name||!version) return null;
  const icon=s(p?.icon), readme=s(p?.readme), pkg=s(p?.package)??s(p?.repo);
  return { id,name,version, summary:s(p?.summary), author:s(p?.author), license:s(p?.license),
    icon: icon? joinUrl(base, icon.replace(/^\.\//,'')) : undefined,
    README: readme? joinUrl(base, readme.replace(/^\.\//,'')) : undefined,
    packageUrl: pkg, categories: Array.isArray(p?.categories)?p.categories.filter((x:any)=>typeof x==='string'):undefined,
    verified: !!p?.signature };
}
async function fetchWithTimeout(url:string,ms=8000,retries=1){
  let last:any;
  for(let i=0;i<=retries;i++){
    const c=new AbortController(); const t=setTimeout(()=>c.abort(),ms);
    try{ const r=await fetch(url,{signal:c.signal,cache:'no-store'}); clearTimeout(t);
      if(!r.ok) throw new Error(`${r.status} ${r.statusText}`); return r;
    }catch(e){ clearTimeout(t); last=e; if(i===retries) throw last; }
  } throw new Error('unreachable'); }
export async function fetchRegistry(){
  const bases=buildBases(); let last:any;
  for(const b of bases){
    try{ const r=await fetchWithTimeout(joinUrl(b,'registry/index.json'),8000,1);
      const idx=await r.json() as RegistryIndex; const out:any[]=[];
      for(const p of idx.plugins||[]){ const c=coerce(p,b); if(c) out.push(c); }
      return out;
    }catch(e){ last=e; }
  } throw new Error(`App Store index fetch failed (${String(last)})`);
}
function apiBase(){ return reqEnv('VITE_SUPERNET_API', SUPERNET_API).replace(/\/+$/,'') }
export async function installPlugin(p:ForgePlugin){
  const r=await fetch(`${apiBase()}/api/plugins/install`,{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({id:p.id,version:p.version,source:p.packageUrl,verifySignature:true,enable:true})});
  if(!r.ok){const msg=await r.text().catch(()=>'' ); return {ok:false,error:`Install failed ${r.status} ${msg}`};}
  try{return await r.json();}catch{return {ok:true};}
}
export async function listInstalled():Promise<string[]>{ const r=await fetch(`${apiBase()}/api/plugins/list`);
  if(!r.ok) return []; try{ const d=await r.json(); if(Array.isArray(d)) return d; if(Array.isArray((d as any).plugins)) return (d as any).plugins; }catch{} return []; }
export async function disablePlugin(id:string){ const r=await fetch(`${apiBase()}/api/plugins/disable`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}); return r.ok;}
export async function uninstallPlugin(id:string){ const r=await fetch(`${apiBase()}/api/plugins/uninstall`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}); return r.ok;}
export async function statusPlugin(id:string){ const r=await fetch(`${apiBase()}/api/plugins/status?id=${encodeURIComponent(id)}`); if(!r.ok) return null; try{return await r.json();}catch{return null;}}
