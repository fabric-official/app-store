\
#!/usr/bin/env node
// Apply alias to vite.config.ts and tsconfig.json, and inject /agents route if missing.
import fs from "fs";
import path from "path";

const projectRoot = process.argv[2] || ".";

function safeRead(p) { try { return fs.readFileSync(p, "utf8"); } catch { return null; } }
function safeWrite(p, s) { fs.writeFileSync(p, s, "utf8"); }

// tsconfig paths
const tsPath = path.join(projectRoot, "tsconfig.json");
const tsRaw = safeRead(tsPath);
if (tsRaw) {
  try {
    const ts = JSON.parse(tsRaw);
    ts.compilerOptions = ts.compilerOptions || {};
    ts.compilerOptions.baseUrl = ts.compilerOptions.baseUrl || ".";
    ts.compilerOptions.paths = ts.compilerOptions.paths || {};
    if (!ts.compilerOptions.paths["@/*"]) ts.compilerOptions.paths["@/*"] = ["src/*"];
    safeWrite(tsPath, JSON.stringify(ts, null, 2));
    console.log("[OK] tsconfig alias set");
  } catch (e) {
    console.log("[WARN] tsconfig parse failed:", e.message);
  }
}

// vite alias
const vitePath = path.join(projectRoot, "vite.config.ts");
let vite = safeRead(vitePath);
if (vite && !vite.includes("alias:{") && !vite.includes("alias: {")) {
  vite = vite.replace(/defineConfig\(\{([\s\S]*?)\}\)/, (m, inner)=>{
    const aliasBlock = `resolve:{ alias:{ "@": require("path").resolve(__dirname, "src") } },`;
    return `defineConfig({ ${aliasBlock}${inner} })`;
  });
  safeWrite(vitePath, vite);
  console.log("[OK] vite alias injected");
}

// routes
const routesPath = path.join(projectRoot, "src", "routes.ts");
let routes = safeRead(routesPath);
if (routes) {
  if (!routes.includes('import AgentsPage from "@/pages/Agents"')) {
    routes = `import AgentsPage from "@/pages/Agents"\n` + routes;
  }
  if (!routes.includes('path: "/agents"')) {
    routes += `\n// injected by Forge Prod Pack\n(routes as any).push?.({ path: "/agents", element: <AgentsPage /> });\n`;
    safeWrite(routesPath, routes);
    console.log("[OK] /agents route injected");
  } else {
    console.log("[OK] /agents route already present");
  }
}
