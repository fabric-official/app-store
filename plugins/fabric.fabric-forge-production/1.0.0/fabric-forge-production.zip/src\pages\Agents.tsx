import { useEffect, useMemo, useState } from "react";
import { fetchRegistry, installPlugin, listInstalled, disablePlugin, uninstallPlugin, type ForgePlugin } from "@/api/appStore";
import { AgentCard } from "@/components/AgentCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

const PAGE_SIZE = 24;

export default function AgentsPage() {
  const [all, setAll] = useState<ForgePlugin[]>([]);
  const [installed, setInstalled] = useState<string[]>([]);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const [reg, inst] = await Promise.all([fetchRegistry(), listInstalled()]);
        setAll(reg);
        setInstalled(inst);
      } catch (e: any) {
        setErr(e?.message ?? "Failed to load App Store");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return all;
    return all.filter(p =>
      [p.name, p.summary, p.author, ...(p.categories ?? [])]
        .filter(Boolean)
        .some(s => (s as string).toLowerCase().includes(needle))
    );
  }, [all, q]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  async function onInstall(p: ForgePlugin) {
    const res = await installPlugin(p);
    if (!res.ok) { setErr(res.error ?? "Install failed"); return; }
    const next = await listInstalled(); setInstalled(next);
  }
  async function onDisable(id: string) {
    const ok = await disablePlugin(id).catch(() => false);
    if (!ok) setErr("Disable not supported by server");
  }
  async function onUninstall(id: string) {
    const ok = await uninstallPlugin(id).catch(() => false);
    if (!ok) setErr("Uninstall not supported by server");
    const next = await listInstalled(); setInstalled(next);
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <Input placeholder="Search agents & plugins…" value={q} onChange={e => { setQ(e.target.value); setPage(0); }} />
        <Button variant="outline" onClick={() => { setQ(""); setPage(0); }}>Clear</Button>
        <div className="ml-auto text-sm opacity-70">{filtered.length} results</div>
      </div>

      {err && (<Alert variant="destructive"><AlertDescription>{err}</AlertDescription></Alert>)}

      {loading ? (<div className="text-sm opacity-70">Loading App Store…</div>) : (
        <>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pageItems.map(p => (
              <AgentCard key={`${p.id}@${p.version}`} plugin={p}
                installed={installed.includes(p.id)}
                onInstall={() => onInstall(p)}
                onDisable={() => onDisable(p.id)}
                onUninstall={() => onUninstall(p.id)} />
            ))}
          </div>
          {pageCount > 1 && (
            <div className="flex items-center justify-center gap-3 mt-4">
              <Button variant="outline" disabled={page === 0} onClick={() => setPage(p => Math.max(0, p - 1))}>Prev</Button>
              <div className="text-sm">Page {page + 1} / {pageCount}</div>
              <Button variant="outline" disabled={page + 1 >= pageCount} onClick={() => setPage(p => Math.min(pageCount - 1, p + 1))}>Next</Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
