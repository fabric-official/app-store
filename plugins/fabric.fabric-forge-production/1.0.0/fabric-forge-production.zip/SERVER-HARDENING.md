# Server Hardening (CSP / CORS / Signatures)

- **CSP** (example Express middleware):
```ts
app.use((_, res, next) => {
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; img-src 'self' data: https://raw.githubusercontent.com https://cdn.jsdelivr.net; " +
    "style-src 'self' 'unsafe-inline'; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
  next();
});
```

- **CORS**: if you self-host the App Store under another domain, allow GET for `/registry/*` and `/plugins/*`.

- **Signature verification** (SuperNet):
  - cosign verify of `registry/index.json` and plugin bundle
  - pin public key(s), support rotation
  - emit `PluginInstallDelta`, `PluginEnableDelta`, `PluginDisableDelta`, `PluginUninstallDelta` to audit
