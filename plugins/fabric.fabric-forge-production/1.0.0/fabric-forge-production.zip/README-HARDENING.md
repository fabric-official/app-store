
# Forge Hardening Notes (Applied)

This patch adds:
- App Store repo/branch pinning + RAW/CDN fallback
- Timeout + retry for registry fetch
- Install + Disable + Uninstall client hooks
- Pagination + better errors on Agents page
- Safe README rendering hook via `MarkdownRenderer` (uses existing `utils/sanitize.ts`)
- Env template with your exact branch

**Server requirements** (SuperNet):
- `POST /api/plugins/install` accepts `{ id, version, source, verifySignature, enable }`
- `GET  /api/plugins/list` returns `string[]` or `{plugins:string[]}`
- Optional: `POST /api/plugins/disable`, `POST /api/plugins/uninstall`, `GET /api/plugins/status?id=`

**Security / Ops**:
- Verify signatures server-side (cosign), pin trust keys, support key rotation
- Enforce plugin policy/permissions and energy budgets
- Sanitize README HTML; consider CSP and referrer policy
- For massive catalogs, shard or paginate the registry server-side
