import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Email Gateway v1.0.0</h1><p>SMTP/IMAP bridge for User Forge email; store-and-forward via DTN queue.</p></div>);
}