const guessBase = () => {
  const w = globalThis as any;
  return w.__API_BASE__ || import.meta?.env?.VITE_API_BASE || "";
};

export async function getStatus(){
  const bases = [
    guessBase() ? guessBase() + "/synth/status" : null,
    "http://localhost:7777/status",
  ].filter(Boolean) as string[];

  let lastErr: any = null;
  for(const url of bases){
    try{
      const res = await fetch(url, { cache: "no-cache" });
      if(res.ok){
        return await res.json();
      }
      lastErr = new Error(`HTTP ${res.status}`);
    }catch(e:any){
      lastErr = e;
    }
  }
  throw lastErr || new Error("status unavailable");
}
