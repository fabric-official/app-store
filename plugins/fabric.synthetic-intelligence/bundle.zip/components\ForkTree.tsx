import React from "react";

type Event = { ts:string; level:string; target?:string; msg:string; detail?:string };

export function ForkTree({ events }: { events: Event[] }){
  const byTarget = new Map<string, Event[]>();
  for(const e of events){
    const key = e.target || "system";
    const arr = byTarget.get(key) || [];
    arr.push(e);
    byTarget.set(key, arr);
  }
  const targets = Array.from(byTarget.keys());

  return (
    <div className="rounded-2xl border p-4">
      <h2 className="font-medium mb-3">Build Chain</h2>
      <div className="space-y-4">
        {targets.length === 0 && <div className="text-sm text-gray-500">No activity yet.</div>}
        {targets.map((t)=>{
          const evs = byTarget.get(t)!;
          return (
            <div key={t}>
              <div className="text-sm font-semibold mb-1">{t}</div>
              <div className="flex items-center gap-2 flex-wrap">
                {evs.map((e, i)=>(
                  <div key={i} className={"px-2 py-1 text-xs rounded border " + (e.level === "error" ? "border-red-300 bg-red-50" : "border-gray-300 bg-gray-50")}>
                    <span className="opacity-60">{new Date(e.ts).toLocaleTimeString()}</span>{" "}• {e.msg}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
