# Synthetic Intelligence — Dashboard Plugin Package

This is a **self-contained plugin artifact** with `plugin.json` at the archive root.
Your App Store can ingest this zip directly and mount it under the dashboard plugins directory.

## Files
- plugin.json  (kind: plugin-page, route: /plugins/synthetic-intelligence)
- index.tsx    (entry)
- components/  (ForkTree, EnergyMeter, AuditLog)
- lib/api.ts   (status polling)

## Expected install path (when extracted by the store)
apps/dashboard/plugins/synthetic-intelligence/*
