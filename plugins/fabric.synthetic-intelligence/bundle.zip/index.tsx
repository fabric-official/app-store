import React, { useEffect, useState } from "react";
import { ForkTree } from "./components/ForkTree";
import { EnergyMeter } from "./components/EnergyMeter";
import { AuditLog } from "./components/AuditLog";
import { getStatus } from "./lib/api";

export default function SyntheticIntelligencePage() {
  const [status, setStatus] = useState<any>(null);
  const [err, setErr] = useState<string| null>(null);

  useEffect(() => {
    let mounted = true;
    async function poll(){
      try{
        const s = await getStatus();
        if(mounted) setStatus(s);
      }catch(e:any){
        if(mounted) setErr(e?.message || String(e));
      }finally{
        setTimeout(poll, 1500);
      }
    }
    poll();
    return () => { mounted = false; };
  }, []);

  return (
    <div className="p-6 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Synthetic Intelligence</h1>
        {status?.ok !== undefined && (
          <span className={"px-2 py-1 rounded text-sm " + (status.ok ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700")}>
            {status.ok ? "Healthy" : "Degraded"}
          </span>
        )}
      </header>

      {err && <div className="text-red-600 text-sm">Error: {err}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ForkTree events={status?.events || []} />
        </div>
        <div className="lg:col-span-1">
          <EnergyMeter status={status} />
        </div>
      </div>

      <AuditLog events={status?.events || []} />
    </div>
  );
}
