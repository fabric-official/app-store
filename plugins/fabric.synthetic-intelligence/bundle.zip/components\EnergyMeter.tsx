import React from "react";

export function EnergyMeter({ status }: { status:any }){
  const used = Math.min(100, Math.floor((status?.events?.length || 0) * 7));
  return (
    <div className="rounded-2xl border p-4">
      <h2 className="font-medium mb-3">Energy</h2>
      <div className="h-3 w-full bg-gray-100 rounded">
        <div className="h-3 rounded" style={{ width: used + "%" , background: "#3b82f6" }}></div>
      </div>
      <div className="text-xs text-gray-500 mt-2">{used}% budget (visual)</div>
    </div>
  );
}
