import React from "react";

type Event = { ts:string; level:string; target?:string; msg:string; detail?:string };

export function AuditLog({ events }: { events: Event[] }){
  const ev = [...events].reverse().slice(0, 200);
  return (
    <div className="rounded-2xl border p-4">
      <h2 className="font-medium mb-3">Audit</h2>
      <div className="space-y-2 max-h-96 overflow-auto pr-2">
        {ev.length === 0 && <div className="text-sm text-gray-500">No audit events yet.</div>}
        {ev.map((e, i)=> (
          <div key={i} className={"text-sm p-2 rounded " + (e.level === "error" ? "bg-red-50" : "bg-gray-50")}>
            <div className="flex items-center justify-between">
              <div className="font-mono text-xs opacity-70">{new Date(e.ts).toLocaleString()}</div>
              <div className={"text-xs px-1 rounded " + (e.level === "error" ? "bg-red-200 text-red-800" : "bg-gray-200 text-gray-800")}>{e.level}</div>
            </div>
            <div className="mt-1">{e.msg}</div>
            {e.detail && <pre className="text-xs mt-1 whitespace-pre-wrap opacity-80">{e.detail}</pre>}
          </div>
        ))}
      </div>
    </div>
  );
}
