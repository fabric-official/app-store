import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Bridge: LoRa v1.0.0</h1><p>LoRa bridge via Serial (AT/transparent mode); KISS-framed packets for DTN bundles.</p></div>);
}