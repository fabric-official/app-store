import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Debug Runner v1.0.0</h1><p>Local sandbox runner for agents/plugins with live logs and restart.</p></div>);
}