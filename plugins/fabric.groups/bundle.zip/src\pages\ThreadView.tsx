import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function ThreadView() {
  const id = window.location.pathname.split('/').pop()!;
  const [thread, setThread] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [reply, setReply] = useState('');
  const [err, setErr] = useState<string>('');

  useEffect(() => {
    (async () => {
      try {
        // Minimal thread fetch by reading first post via messages API (for demo simplicity).
        // In a full integration, expose GET /threads/:id to fetch metadata + posts.
        const msgs = await api(`/chat/rooms`); // left as-is; use your app's state to find room
        setErr('Open the group page and create threads/messages.'); 
      } catch (e:any) { setErr(e.message); }
    })();
  }, [id]);

  async function send() {
    try {
      // This placeholder demonstrates reply via posts API
      await api(`/threads/${id}/posts`, { method: 'POST', body: JSON.stringify({ content_md: reply }) });
      setReply('');
      // Re-fetch posts (not implemented in sample UI); in your app, call a /threads/:id endpoint.
    } catch (e:any) { setErr(e.message); }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-4">
        <a href="/groups" className="text-sm text-gray-500">&larr; Back</a>
      </div>
      <h1 className="text-xl font-bold mb-2">Thread</h1>
      {err && <div className="text-sm text-red-500 mb-2">{err}</div>}
      <div className="border rounded-2xl p-4">
        <textarea className="border rounded px-3 py-2 w-full mb-2" rows={4}
          placeholder="Write a reply (Markdown)" value={reply} onChange={e=>setReply(e.target.value)} />
        <button className="px-3 py-2 rounded bg-black text-white" onClick={send}>Reply</button>
      </div>
    </div>
  );
}
