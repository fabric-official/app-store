import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function GroupHome() {
  const slug = window.location.pathname.split('/').pop()!;
  const [group, setGroup] = useState<any>(null);
  const [threads, setThreads] = useState<any[]>([]);
  const [newTitle, setNewTitle] = useState('');
  const [newBody, setNewBody] = useState('');
  const [err, setErr] = useState<string>('');

  useEffect(() => {
    (async () => {
      try {
        const g = await api(`/groups/${slug}`);
        setGroup(g.group);
        const t = await api(`/groups/${g.group.id}/threads`);
        setThreads(t.threads);
      } catch (e:any) { setErr(e.message); }
    })();
  }, [slug]);

  async function createThread() {
    try {
      await api(`/groups/${group.id}/threads`, {
        method: 'POST',
        body: JSON.stringify({ title: newTitle, kind: 'discussion', content_md: newBody })
      });
      const t = await api(`/groups/${group.id}/threads`);
      setThreads(t.threads);
      setNewTitle(''); setNewBody('');
    } catch (e:any) { setErr(e.message); }
  }

  if (err) return <div className="p-6 text-red-500">{err}</div>;
  if (!group) return <div className="p-6">Loading...</div>;
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-gray-200" />
        <div>
          <h1 className="text-2xl font-bold">{group.name}</h1>
          <div className="text-gray-600">{group.bio}</div>
        </div>
      </div>

      <div className="mb-6 border rounded-2xl p-4">
        <h2 className="font-semibold mb-2">Start a discussion</h2>
        <input className="border rounded px-3 py-2 w-full mb-2" placeholder="Title"
               value={newTitle} onChange={e=>setNewTitle(e.target.value)} />
        <textarea className="border rounded px-3 py-2 w-full mb-2" placeholder="Write something... (Markdown)"
               value={newBody} onChange={e=>setNewBody(e.target.value)} rows={5} />
        <button className="px-3 py-2 rounded bg-black text-white" onClick={createThread}>Post</button>
      </div>

      <div className="space-y-3">
        {threads.map(t => (
          <a key={t.id} className="block border rounded-2xl p-4 hover:shadow" href={`/groups/thread/${t.id}`}>
            <div className="text-sm text-gray-500">{new Date(t.created_at).toLocaleString()}</div>
            <div className="font-semibold">{t.title}</div>
            <div className="text-xs uppercase text-gray-500">{t.kind}</div>
          </a>
        ))}
      </div>
    </div>
  );
}
