import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function GroupsIndex() {
  const [groups, setGroups] = useState<any[]>([]);
  const [err, setErr] = useState<string>('');
  useEffect(() => {
    (async () => {
      try {
        // This demo assumes an index endpoint; if not, show instructions.
        // You can fetch featured groups by slug list in your app.
        setErr('Use search or navigate to known slugs.'); 
      } catch (e:any) { setErr(e.message); }
    })();
  }, []);
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Communities</h1>
      {err && <div className="text-sm text-red-500 mb-2">{err}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {groups.map(g => (
          <a key={g.id} className="border rounded-2xl p-4 hover:shadow" href={`/groups/${g.slug}`}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gray-200" />
              <div>
                <div className="font-semibold">{g.name}</div>
                <div className="text-sm text-gray-500">{g.bio}</div>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
