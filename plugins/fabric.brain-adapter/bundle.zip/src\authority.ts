import type { BrainCaps } from './types';

/**
 * The adapter never embeds Supernet logic; it *consumes* it.
 * The host must expose `window.SupernetAuthority` implementing BrainCaps.
 */
declare global {
  interface Window { SupernetAuthority?: BrainCaps }
}

const NOOP: BrainCaps = Object.freeze({
  async energy(){ return { remaining: 0, limit: 0 }; },
  async mintEpoch(){ return { ok:false }; },
  async mintWeights(){ return { ok:false }; },
  async storage(){ return { ok:false, grantedBytes: 0 }; },
  async swarm(){ return { ok:false }; },
  telemetry(/* _evt */){ /* noop */ },
});

export function getAuthority(): BrainCaps {
  const caps = (typeof window !== 'undefined' && (window as any).SupernetAuthority)
    ? (window as any).SupernetAuthority as BrainCaps
    : NOOP;
  try { return Object.freeze({ ...caps }); } catch { return caps; }
}
