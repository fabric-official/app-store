import type { PluginLike } from './types'
import { getAuthority } from './authority'

declare global {
  interface Window {
    FabricPlugins?: { register: (p: any) => void; _registry?: any[] };
    __FAB_BRAIN_PROXY_INSTALLED__?: boolean;
  }
}

type Energy = { remaining: number; limit: number }
type Safe<T> = Promise<{ ok: boolean; data?: T; error?: string }>

const WRAP_TAG = Symbol.for('__fab_brain_wrapped__')

function isNonEmptyString(x: unknown): x is string {
  return typeof x === 'string' && x.length > 0
}
function isPositiveNumber(x: unknown): x is number {
  return typeof x === 'number' && isFinite(x) && x > 0
}

function safeTelemetry(kind: string, pluginId: string, data?: any) {
  try { getAuthority().telemetry({ pluginId, kind, data }) } catch {}
}

/**
 * Create a **plugin-scoped, read-only** capability facade.
 * Prevents plugins from mutating or capturing raw authority object.
 */
function scopedCaps(pluginId: string) {
  const auth = getAuthority()

  async function energy(): Promise<Energy> {
    try { return await auth.energy() } catch { return { remaining: 0, limit: 0 } }
  }

  const api = {
    energy,

    async mintEpoch(req: { agentId: string; reason: string }): Safe<{ epochId: string }> {
      if (!req || !isNonEmptyString(req.agentId) || !isNonEmptyString(req.reason)) {
        return { ok: false, error: 'invalid-args' }
      }
      const e = await energy()
      if (e.remaining <= 0) {
        safeTelemetry('deny-mintEpoch-no-energy', pluginId, { agentId: req.agentId })
        return { ok: false, error: 'insufficient-energy' }
      }
      try {
        const r = await (getAuthority()).mintEpoch({ agentId: req.agentId, reason: req.reason })
        if (r?.ok && (r as any).epochId) {
          const epochId = (r as any).epochId as string
          safeTelemetry('mintEpoch', pluginId, { agentId: req.agentId, epochId })
          return { ok: true, data: { epochId } }
        }
        return { ok: false, error: 'mint-failed' }
      } catch (e:any) {
        safeTelemetry('error-mintEpoch', pluginId, { agentId: req.agentId, error: String(e) })
        return { ok: false, error: 'exception' }
      }
    },

    async mintWeights(req: { agentId: string; deltaMB: number; tag?: string }): Safe<{ weightId: string }> {
      if (!req || !isNonEmptyString(req.agentId) || !isPositiveNumber(req.deltaMB)) {
        return { ok: false, error: 'invalid-args' }
      }
      const e = await energy()
      if (e.remaining <= 0) {
        safeTelemetry('deny-mintWeights-no-energy', pluginId, { agentId: req.agentId, mb: req.deltaMB })
        return { ok: false, error: 'insufficient-energy' }
      }
      try {
        const r = await (getAuthority()).mintWeights({ agentId: req.agentId, deltaMB: req.deltaMB, tag: req.tag })
        if (r?.ok && (r as any).weightId) {
          const weightId = (r as any).weightId as string
          safeTelemetry('mintWeights', pluginId, { agentId: req.agentId, weightId, mb: req.deltaMB })
          return { ok: true, data: { weightId } }
        }
        return { ok: false, error: 'mint-failed' }
      } catch (e:any) {
        safeTelemetry('error-mintWeights', pluginId, { agentId: req.agentId, error: String(e) })
        return { ok: false, error: 'exception' }
      }
    },

    async storage(req: { bytes: number; ttlSec?: number }): Safe<{ grantedBytes: number }> {
      if (!req || !isPositiveNumber(req.bytes)) {
        return { ok: false, error: 'invalid-args' }
      }
      try {
        const r = await (getAuthority()).storage({ pluginId, bytes: req.bytes, ttlSec: req.ttlSec })
        if (r?.ok && typeof (r as any).grantedBytes === 'number') {
          const grantedBytes = (r as any).grantedBytes as number
          safeTelemetry('storage-grant', pluginId, { bytes: grantedBytes })
          return { ok: true, data: { grantedBytes } }
        }
        return { ok: false, error: 'denied' }
      } catch (e:any) {
        safeTelemetry('error-storage', pluginId, { error: String(e) })
        return { ok: false, error: 'exception' }
      }
    },

    async swarm(req: { agentId: string; task: string; hints?: any }): Safe<{ swarmId: string }> {
      if (typeof (getAuthority() as any).swarm !== 'function') {
        return { ok: false, error: 'unavailable' }
      }
      if (!req || !isNonEmptyString(req.agentId) || !isNonEmptyString(req.task)) {
        return { ok: false, error: 'invalid-args' }
      }
      const e = await energy()
      if (e.remaining <= 0) {
        safeTelemetry('deny-swarm-no-energy', pluginId, { agentId: req.agentId })
        return { ok: false, error: 'insufficient-energy' }
      }
      try {
        const r = await (getAuthority() as any).swarm({ agentId: req.agentId, task: req.task, hints: req.hints })
        if (r?.ok && (r as any).swarmId) {
          const swarmId = (r as any).swarmId as string
          safeTelemetry('swarm-dispatch', pluginId, { agentId: req.agentId, swarmId })
          return { ok: true, data: { swarmId } }
        }
        return { ok: false, error: 'dispatch-failed' }
      } catch (e:any) {
        safeTelemetry('error-swarm', pluginId, { error: String(e) })
        return { ok: false, error: 'exception' }
      }
    },
  }

  try { Object.seal(api) } catch {}
  try { return Object.freeze(api) } catch { return api as any }
}

/**
 * Wrap a plugin so its onRegister receives a **scoped brain ctx**.
 */
export function wrapWithBrain(p: PluginLike): PluginLike {
  const anyP = p as any
  if (anyP && anyP[WRAP_TAG]) return p

  const pluginId = (p as any)?.id ?? 'unknown'
  const wrapped: PluginLike = {
    ...p,
    onRegister(ctx: any) {
      const brain = scopedCaps(pluginId)
      const safeCtx = Object.freeze({ ...ctx, brain, pluginId })
      try { p?.onRegister?.(safeCtx) } catch (e:any) {
        safeTelemetry('error-plugin-onRegister', pluginId, { error: String(e) })
      }
    }
  }
  try { Object.defineProperty(wrapped as any, WRAP_TAG, { value: true, enumerable: false }) } catch {}
  try { Object.freeze(wrapped as any) } catch {}
  return wrapped
}

/**
 * Install a hardened proxy around register(); idempotent, non-configurable.
 */
export function installProxy() {
  const w = (typeof window !== 'undefined' ? (window as any) : undefined)
  if (!w || !w.FabricPlugins || typeof w.FabricPlugins.register !== 'function') return
  if (w.__FAB_BRAIN_PROXY_INSTALLED__) return

  const original = w.FabricPlugins.register.bind(w.FabricPlugins)

  function securedRegister(p: any) {
    return original(wrapWithBrain(p))
  }

  try {
    Object.defineProperty(w.FabricPlugins, 'register', {
      value: securedRegister,
      writable: false,
      configurable: false,
      enumerable: true
    })
  } catch {}

  try { Object.seal(w.FabricPlugins) } catch {}
  w.__FAB_BRAIN_PROXY_INSTALLED__ = true

  // Optional: re-emit telemetry for already-registered plugins
  try {
    const list = Array.isArray(w.FabricPlugins._registry) ? w.FabricPlugins._registry : []
    for (const p of list) {
      const id = p?.id ?? 'unknown'
      const ver = p?.version ?? 'unknown'
      safeTelemetry('plugin-detected', id, { version: ver })
    }
  } catch {}
}

/**
 * Retrofit hook for hosts that keep a prior list.
 */
export function retrofitPreviouslyRegistered(plugins: Array<{ id: string; version: string }>) {
  for (const p of plugins || []) {
    try { safeTelemetry('plugin-detected', p.id, { version: p.version }) } catch {}
  }
}
