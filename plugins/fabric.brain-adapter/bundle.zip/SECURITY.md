# Security Policy

## Supported Versions
- `@fabric-official/brain-adapter` **1.1.0** (hardened)

## Threat Model (summary)
- Prevent plugins from mutating or capturing raw authority objects.
- Enforce least-privilege via a scoped, frozen facade.
- Validate inputs for epoch/weights/storage/swarm and preflight energy budgets.
- Idempotent, tamper-resistant proxy installation for `FabricPlugins.register`.

## Reporting a Vulnerability
Please open a private advisory or email security@atomic.ltd with a minimal PoC.
