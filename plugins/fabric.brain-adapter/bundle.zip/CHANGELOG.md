# Changelog

## 1.1.0 — Hardened release
- Idempotent, non-configurable proxy install for `FabricPlugins.register`.
- Scoped, frozen capability facade injected as `ctx.brain`.
- Input validation + energy preflight for `mintEpoch`, `mintWeights`, `swarm`.
- Storage grants are plugin-scoped and audited via telemetry.
- Double-wrap protections and frozen plugin manifests.
