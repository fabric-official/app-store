export type PluginLike = {
  id: string;
  name: string;
  version: string;
  routes?: any[];
  navItems?: any[];
  widgets?: any[];
  onRegister?: (ctx: any) => void;
};

export type BrainCaps = {
  energy(): Promise<{ remaining: number; limit: number }>;
  mintEpoch(req: { agentId: string; reason: string }): Promise<{ ok: boolean; epochId?: string }>;
  mintWeights(req: { agentId: string; deltaMB: number; tag?: string }): Promise<{ ok: boolean; weightId?: string }>;
  storage(req: { pluginId: string; bytes: number; ttlSec?: number }): Promise<{ ok: boolean; grantedBytes: number }>;
  swarm?(req: { agentId: string; task: string; hints?: any }): Promise<{ ok: boolean; swarmId?: string }>;
  telemetry(evt: { pluginId: string; kind: string; data?: any }): void;
};
