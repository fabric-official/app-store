import "./lib/brain-adapter/index.js";
export default function BrainAdapterBoot(){ return null; }