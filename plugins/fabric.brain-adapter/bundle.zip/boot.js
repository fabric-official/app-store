// Host-side boot: loads the hardened Fabric Brain Adapter (no UI routes)
import './lib/brain-adapter/index.js';
export default function BrainAdapterBoot(){ return null; }
