import { installProxy } from './adapter'

/**
 * Brain Adapter plugin manifest. No routes/nav; host-side only.
 * Installing the module installs the proxy immediately.
 */
installProxy()

const brainAdapterPlugin = {
  id: 'fabric-brain-adapter',
  name: 'Fabric Brain Adapter',
  version: '1.1.0',
  routes: [],
  navItems: [],
  onRegister(ctx: any) {
    try { (window as any).SupernetAuthority?.telemetry?.({ pluginId: 'fabric-brain-adapter', kind: 'adapter-loaded' }) } catch {}
  }
}

export default brainAdapterPlugin
