# Fabric Brain Adapter (App Store Plugin Source)

This is the publishable source folder for the host-side adapter.

- **entry:** `boot.js` (imports the hardened adapter and installs the proxy)
- **lib/brain-adapter/** contains the prebuilt hardened adapter JS files.
- **No routes/nav.** This plugin has no UI; it is a host adapter.
