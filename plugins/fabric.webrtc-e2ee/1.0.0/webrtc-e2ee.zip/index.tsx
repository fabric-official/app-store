import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>WebRTC E2EE Transformer v1.0.0</h1><p>Insertable streams AES-GCM transformer for end-to-end encrypted meetings.</p></div>);
}