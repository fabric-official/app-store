import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Health & Telemetry v1.0.0</h1><p>Node/bridge metrics, DTN queue depth, link status; opt-in telemetry emitter.</p></div>);
}