import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { router as devforge } from "./devforge.js";

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" }));

app.use("/api/devforge", devforge);

const STORE = path.resolve(process.env.APP_STORE_DIR || path.join(process.cwd(), "app-store"));
app.use("/app-store", express.static(STORE));

app.use((_, res, next) => {
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; img-src 'self' data: https://raw.githubusercontent.com https://cdn.jsdelivr.net; " +
    "style-src 'self' 'unsafe-inline'; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
  next();
});

const PORT = Number(process.env.PORT || 8080);
app.listen(PORT, () => console.log("[devforge-powerpack] listening on", PORT));
