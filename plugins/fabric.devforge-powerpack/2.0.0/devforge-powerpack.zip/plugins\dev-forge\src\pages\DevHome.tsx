import { useState } from "react";
import { dev } from "@/api/devforge";

export default function DevHome(){
  const [id, setId] = useState("hello-plugin");
  const [name, setName] = useState("Hello Plugin");
  const [version, setVersion] = useState("0.0.1");
  const [out, setOut] = useState("");

  async function create(){ const r = await dev.init({ id, name, version }); setOut(JSON.stringify(r,null,2)); }

  return (
    <div className="p-6 space-y-3">
      <h1 className="text-xl font-bold">Developer Forge</h1>
      <div className="grid md:grid-cols-3 gap-2">
        <input className="border p-2 rounded" value={id} onChange={e=>setId(e.target.value)} placeholder="id"/>
        <input className="border p-2 rounded" value={name} onChange={e=>setName(e.target.value)} placeholder="name"/>
        <input className="border p-2 rounded" value={version} onChange={e=>setVersion(e.target.value)} placeholder="version"/>
      </div>
      <div className="flex gap-2">
        <a className="px-3 py-2 border rounded" href="/dev/editor">Open Editor</a>
        <a className="px-3 py-2 border rounded" href="/dev/pipeline">Open Pipeline</a>
      </div>
      <pre className="bg-gray-100 p-2 rounded text-xs h-48 overflow-auto">{out}</pre>
    </div>
  );
}
