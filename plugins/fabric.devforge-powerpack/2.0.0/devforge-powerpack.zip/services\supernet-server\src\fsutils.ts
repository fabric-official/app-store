import fs from "fs";
import path from "path";

export function mkdirp(p: string){ fs.mkdirSync(p, { recursive: true }); }
export function exists(p: string){ try { fs.accessSync(p); return true; } catch { return false; } }
export function read(p: string){ return fs.readFileSync(p, "utf8"); }
export function write(p: string, s: string | Buffer){ mkdirp(path.dirname(p)); fs.writeFileSync(p, s); }
export function rmrf(p: string){ fs.rmSync(p, { recursive: true, force: true }); }
