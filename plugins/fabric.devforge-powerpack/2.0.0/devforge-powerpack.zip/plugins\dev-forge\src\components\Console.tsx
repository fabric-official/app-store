export function Console({ logs }:{ logs:string[] }){
  return <pre className="bg-black text-green-400 p-2 h-64 overflow-auto rounded text-xs">{logs.join("\n")}</pre>;
}
