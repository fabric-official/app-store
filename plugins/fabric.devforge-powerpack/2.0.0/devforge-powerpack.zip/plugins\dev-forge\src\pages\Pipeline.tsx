import { useState } from "react";
import { dev } from "@/api/devforge";
import { Console } from "@/components";

export default function Pipeline(){
  const [project, setProject] = useState("hello-plugin");
  const [logs, setLogs] = useState<string[]>([]);
  const out = (s:string)=>setLogs(l=>[...l,s]);
  async function step(name:string, fn:()=>Promise<any>){ out(`▶ ${name}`); const r = await fn(); out(JSON.stringify(r)); }

  return (
    <div className="p-6 space-y-3">
      <h1 className="text-xl font-bold">Build → Test → Cosign → Verify → Stage → Install → Push → PR</h1>
      <div className="flex gap-2">
        <input className="border p-2 rounded" value={project} onChange={e=>setProject(e.target.value)} placeholder="project id"/>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Build",()=>dev.build(project))}>Build</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Test",()=>dev.test(project))}>Test</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Cosign",()=>dev.cosign(project))}>Cosign</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Verify",()=>dev.verify(project))}>Verify</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Stage",()=>dev.stage(project))}>Stage</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Install (Fabric)",()=>dev.install(project))}>Install</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("Push",()=>dev.push("devforge: publish"))}>Push</button>
        <button className="px-3 py-2 border rounded" onClick={()=>step("PR",()=>dev.pr("DevForge publish","main"))}>PR</button>
      </div>
      <Console logs={logs}/>
    </div>
  );
}
