import { useEffect, useRef, useState } from "react";
import * as monaco from "monaco-editor";
import { dev } from "@/api/devforge";
import { FileTree, Tabs, Console } from "@/components";

export default function Editor(){
  const [project, setProject] = useState("hello-plugin");
  const [files, setFiles] = useState<string[]>([]);
  const [openFiles, setOpenFiles] = useState<string[]>([]);
  const [active, setActive] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const editorRef = useRef<HTMLDivElement>(null);
  const inst = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);

  async function refresh(){ const r = await dev.fs.list(project); setFiles(r.files || []); }
  useEffect(()=>{ refresh(); }, [project]);

  useEffect(()=>{ if (editorRef.current && !inst.current){ inst.current = monaco.editor.create(editorRef.current, { value: "", language: "typescript", automaticLayout: true, minimap:{enabled:false} }); } },[]);

  async function open(f: string){
    const r = await dev.fs.read(project, f);
    if (!openFiles.includes(f)) setOpenFiles([...openFiles, f]);
    setActive(openFiles.indexOf(f) >= 0 ? openFiles.indexOf(f) : openFiles.length);
    inst.current?.setValue(r.content || "");
  }
  async function save(){
    const f = openFiles[active]; if (!f) return;
    const content = inst.current?.getValue() || "";
    await dev.fs.write(project, f, content);
    setLogs(l=>[...l, `[saved] ${f}`]);
  }
  async function createFile(){
    const p = prompt("New file path (relative)","src/new.ts"); if(!p) return;
    await dev.fs.write(project, p, "// new file\n");
    refresh(); open(p);
  }
  async function deleteFile(){
    const f = openFiles[active]; if(!f) return;
    await dev.fs.delete(project, f); setOpenFiles(openFiles.filter(x=>x!==f)); setActive(0); refresh();
  }
  async function find(){
    const q = prompt("Find in files","manifest"); if(!q) return;
    const r = await dev.fs.search(project, q);
    setLogs(l=>[...l, `-- search: ${q} --`, ...r.hits.map((h:any)=>`${h.file}:${h.line} ${h.text}`)]);
  }

  return (
    <div className="p-4 grid grid-cols-4 gap-3">
      <div className="col-span-1 border rounded p-2">
        <div className="flex gap-2 mb-2">
          <input className="border p-1 text-xs rounded w-full" value={project} onChange={e=>setProject(e.target.value)}/>
          <button className="px-2 py-1 text-xs border rounded" onClick={refresh}>Refresh</button>
        </div>
        <div className="flex gap-1 mb-2">
          <button className="px-2 py-1 text-xs border rounded" onClick={createFile}>+ File</button>
          <button className="px-2 py-1 text-xs border rounded" onClick={find}>Find</button>
        </div>
        <FileTree files={files} onOpen={open}/>
      </div>
      <div className="col-span-3 border rounded p-2">
        <Tabs items={openFiles.length?openFiles:["(no file)"]} onSelect={setActive} />
        <div ref={editorRef} className="h-[480px] border rounded mt-2"></div>
        <div className="flex gap-2 mt-2">
          <button className="px-3 py-2 border rounded" onClick={save}>Save</button>
          <a className="px-3 py-2 border rounded" href="/dev/tests">Run Tests</a>
          <a className="px-3 py-2 border rounded" href="/dev/pipeline">Pipeline</a>
        </div>
        <Console logs={logs} />
      </div>
    </div>
  );
}
