const E = (import.meta as any).env || {};
const API = (E.VITE_SUPERNET_API as string | undefined)?.replace(/\/+$/,'') || "http://localhost:8080";
const j = (p:string)=>`${API}${p}`;

async function post(p:string, body:any){ const r=await fetch(j(p),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}); const t=await r.text(); try{return JSON.parse(t);}catch{return { raw:t }} }
export const dev = {
  fs: {
    list: (project:string)=>post("/api/devforge/fs/list",{project}),
    read: (project:string,file:string)=>post("/api/devforge/fs/read",{project,file}),
    write: (project:string,file:string,content:string)=>post("/api/devforge/fs/write",{project,file,content}),
    mkdir: (project:string,dir:string)=>post("/api/devforge/fs/mkdir",{project,dir}),
    rename: (project:string,frm:string,to:string)=>post("/api/devforge/fs/rename",{project,from:frm,to}),
    delete: (project:string,target:string)=>post("/api/devforge/fs/delete",{project,target}),
    search: (project:string,q:string)=>post("/api/devforge/fs/search",{project,q}),
  },
  init: (payload:any)=>post("/api/devforge/init",payload),
  build: (project:string)=>post("/api/devforge/build",{project}),
  test: (project:string)=>post("/api/devforge/test",{project}),
  cosign: (project:string)=>post("/api/devforge/cosign",{project}),
  verify: (project:string)=>post("/api/devforge/verify",{project}),
  stage: (project:string)=>post("/api/devforge/stage",{project}),
  install: (project:string)=>post("/api/devforge/install",{project}),
  rollback: (project:string,version:string)=>post("/api/devforge/rollback",{project,version}),
  push: (message?:string)=>post("/api/devforge/push",{message}),
  pr: (title?:string,base?:string)=>post("/api/devforge/pr",{title,base}),
  secrets: {
    set: (key:string,value:string)=>post("/api/devforge/secrets/set",{key,value}),
    list: ()=>post("/api/devforge/secrets/list",{}),
  }
};
