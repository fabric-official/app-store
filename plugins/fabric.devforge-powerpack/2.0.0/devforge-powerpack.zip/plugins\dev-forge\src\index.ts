import { routes } from "./routes";
import { manifest } from "./manifest";
export { routes, manifest };
