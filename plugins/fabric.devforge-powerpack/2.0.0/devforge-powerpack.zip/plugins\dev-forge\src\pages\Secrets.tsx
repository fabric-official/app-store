import { useEffect, useState } from "react";
import { dev } from "@/api/devforge";

export default function Secrets(){
  const [key, setKey] = useState(""); const [val, setVal] = useState(""); const [keys, setKeys] = useState<string[]>([]);
  async function add(){ if(!key||!val) return; await dev.secrets.set(key,val); setKey(""); setVal(""); refresh(); }
  async function refresh(){ const r = await dev.secrets.list(); setKeys(r.keys || []); }
  useEffect(()=>{ refresh(); },[]);
  return (
    <div className="p-6 space-y-3">
      <h1 className="text-xl font-bold">Secrets (encrypted at rest)</h1>
      <div className="grid md:grid-cols-2 gap-2">
        <input className="border p-2 rounded" value={key} onChange={e=>setKey(e.target.value)} placeholder="KEY"/>
        <input className="border p-2 rounded" value={val} onChange={e=>setVal(e.target.value)} placeholder="value"/>
      </div>
      <button className="px-3 py-2 border rounded" onClick={add}>Store</button>
      <div className="text-sm opacity-70">Stored keys:</div>
      <ul className="list-disc pl-6">{keys.map(k=><li key={k}>{k}</li>)}</ul>
    </div>
  );
}
