import { spawnSync } from "child_process";
import fs from "fs";

function run(cmd: string, args: string[], env: Record<string,string|undefined> = {}){
  const out = spawnSync(cmd, args, { stdio: "pipe", encoding: "utf8", env: { ...process.env, ...env } });
  if (out.status !== 0) throw new Error(`[cosign] ${cmd} ${args.join(" ")}\n${out.stderr || out.stdout}`);
  return out.stdout.trim();
}

export function cosignSign(file: string, keyRef: string, password?: string){
  const args = ["sign-blob", "--yes", "--key", keyRef, file];
  const out = run("cosign", args, password ? { COSIGN_PASSWORD: password } : {});
  fs.writeFileSync(file + ".sig", out, "utf8");
  return { sigB64: out, sigPath: file + ".sig" };
}
export function cosignVerify(file: string, keyRef: string, signatureB64: string){
  const sigTmp = file + ".verify.sig";
  fs.writeFileSync(sigTmp, signatureB64, "utf8");
  const args = ["verify-blob", "--key", keyRef, "--signature", sigTmp, file];
  const out = run("cosign", args);
  fs.unlinkSync(sigTmp);
  return out.includes("Verified OK");
}
