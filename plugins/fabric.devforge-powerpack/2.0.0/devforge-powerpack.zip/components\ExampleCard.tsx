﻿import React from "react";
export const ExampleCard = ({ title = "Example" }) => (
  <div style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8 }}>{title}</div>
);
