export const manifest = { id:"fabric.dev-forge", name:"Developer Forge", version:"2.0.0", routes:["/dev","/dev/editor","/dev/tests","/dev/pipeline","/dev/permissions","/dev/secrets"] };
