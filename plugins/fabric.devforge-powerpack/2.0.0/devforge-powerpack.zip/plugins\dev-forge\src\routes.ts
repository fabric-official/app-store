import DevHome from "@/pages/DevHome";
import Editor from "@/pages/Editor";
import Tests from "@/pages/Tests";
import Pipeline from "@/pages/Pipeline";
import Permissions from "@/pages/Permissions";
import Secrets from "@/pages/Secrets";

export const routes = [
  { path: "/dev", element: <DevHome /> },
  { path: "/dev/editor", element: <Editor /> },
  { path: "/dev/tests", element: <Tests /> },
  { path: "/dev/pipeline", element: <Pipeline /> },
  { path: "/dev/permissions", element: <Permissions /> },
  { path: "/dev/secrets", element: <Secrets /> },
];
