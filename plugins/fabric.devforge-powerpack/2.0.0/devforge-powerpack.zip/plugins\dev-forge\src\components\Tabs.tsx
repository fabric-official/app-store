import { useState } from "react";
export function Tabs({ items, onSelect }:{ items:string[], onSelect:(i:number)=>void }){
  const [sel, setSel] = useState(0);
  return (
    <div className="flex gap-2 overflow-x-auto border-b">
      {items.map((t,i)=>(<button key={i} className={"px-2 py-1 text-xs " + (i===sel?"border-b-2 border-black":"opacity-70")} onClick={()=>{setSel(i);onSelect(i)}}>{t}</button>))}
    </div>
  );
}
