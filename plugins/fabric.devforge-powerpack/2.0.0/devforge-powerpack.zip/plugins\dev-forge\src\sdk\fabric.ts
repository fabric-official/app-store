// Minimal Fabric SDK types
export type FabricPluginManifest = {
  id: string; name: string; version: string;
  permissions?: string[];
};
export type SuperNetAPI = {
  installPlugin(input: { id:string; version:string; source:string; verifySignature?:boolean; enable?:boolean }): Promise<{ ok: boolean }>;
};
