import { useEffect, useState } from "react";
import { dev } from "@/api/devforge";

export default function Permissions(){
  const [project, setProject] = useState("hello-plugin");
  const [manifest, setManifest] = useState<any>({ permissions: [] });
  const [msg, setMsg] = useState("");

  async function load(){
    const r = await dev.fs.read(project, "src/index.ts").catch(()=>({content:""}));
    const m = /manifest\s*=\s*(\{[\s\S]*?\})/.exec(r.content || "");
    try { if (m) setManifest(JSON.parse(m[1])); } catch {}
  }
  async function save(){
    const r = await dev.fs.read(project, "src/index.ts"); let s = r.content || "";
    s = s.replace(/manifest\s*=\s*\{[\s\S]*?\}/, `manifest = ${JSON.stringify(manifest,null,2)}`);
    await dev.fs.write(project, "src/index.ts", s); setMsg("Saved");
  }
  useEffect(()=>{ load(); },[project]);

  function toggle(p:string){
    const arr = new Set(manifest.permissions||[]);
    if (arr.has(p)) arr.delete(p); else arr.add(p);
    setManifest({ ...manifest, permissions: Array.from(arr) });
  }

  const caps = ["messaging:send","messaging:receive","contacts:read","contacts:write","devices:list","bridges:configure","crypto:use","files:read","files:write","camera:use","microphone:use"];

  return (
    <div className="p-6 space-y-3">
      <h1 className="text-xl font-bold">Permissions (Capabilities)</h1>
      <div className="flex gap-2">
        <input className="border p-2 rounded" value={project} onChange={e=>setProject(e.target.value)}/>
        <button className="px-3 py-2 border rounded" onClick={load}>Load</button>
        <button className="px-3 py-2 border rounded" onClick={save}>Save</button>
      </div>
      <div className="grid md:grid-cols-2 gap-2">
        {caps.map(c=>(
          <label key={c} className="flex items-center gap-2">
            <input type="checkbox" checked={(manifest.permissions||[]).includes(c)} onChange={()=>toggle(c)} />
            <span>{c}</span>
          </label>
        ))}
      </div>
      <div className="text-sm opacity-70">{msg}</div>
    </div>
  );
}
