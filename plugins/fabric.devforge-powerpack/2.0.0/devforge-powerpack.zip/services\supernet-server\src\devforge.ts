import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { spawn } from "child_process";
import * as esbuild from "esbuild";
import tar from "tar";
import fg from "fast-glob";
import simpleGit from "simple-git";
import { Octokit } from "@octokit/rest";
import { cosignSign, cosignVerify } from "./cosign.js";
import { mkdirp, exists, read, write, rmrf } from "./fsutils.js";

export const router = express.Router();

const WORK = path.resolve(process.env.DEVFORGE_WORK || path.join(process.cwd(), "workspace"));
const STORE = path.resolve(process.env.APP_STORE_DIR || path.join(process.cwd(), "app-store"));
const REG_PATH = path.join(STORE, "registry", "index.json");
const SECRET_KEY = process.env.DEVFORGE_SECRETS_KEY || ""; // AES key (32 bytes base64)

// ---------- File System (multi-file editor) ----------
router.post("/fs/list", async (req, res) => {
  const { project } = req.body || {};
  const dir = path.join(WORK, project);
  const files = await fg(["**/*"], { cwd: dir, dot: true, onlyFiles: true });
  res.json({ files });
});
router.post("/fs/read", (req, res) => {
  const { project, file } = req.body || {};
  const p = path.join(WORK, project, file);
  res.json({ content: read(p) });
});
router.post("/fs/write", (req, res) => {
  const { project, file, content } = req.body || {};
  const p = path.join(WORK, project, file);
  write(p, content);
  res.json({ ok: true });
});
router.post("/fs/mkdir", (req, res) => {
  const { project, dir } = req.body || {};
  mkdirp(path.join(WORK, project, dir));
  res.json({ ok: true });
});
router.post("/fs/rename", (req, res) => {
  const { project, from, to } = req.body || {};
  fs.renameSync(path.join(WORK, project, from), path.join(WORK, project, to));
  res.json({ ok: true });
});
router.post("/fs/delete", (req, res) => {
  const { project, target } = req.body || {};
  rmrf(path.join(WORK, project, target));
  res.json({ ok: true });
});
router.post("/fs/search", async (req, res) => {
  const { project, q } = req.body || {};
  const dir = path.join(WORK, project);
  const files = await fg(["**/*.*"], { cwd: dir, dot: true, onlyFiles: true });
  const hits: any[] = [];
  for (const f of files) {
    const content = read(path.join(dir, f));
    const lines = content.split(/\r?\n/);
    lines.forEach((line, i) => { if (line.includes(q)) hits.push({ file: f, line: i+1, text: line.trim() }); });
  }
  res.json({ hits });
});

// ---------- Templates ----------
router.post("/template/scaffold", (req, res) => {
  const { project, template } = req.body || {};
  const dir = path.join(WORK, project);
  const tplDir = path.resolve(process.cwd(), "templates", template);
  if (!exists(tplDir)) return res.status(400).json({ error: "template not found" });
  const copy = (src: string, dst: string) => {
    const st = fs.statSync(src);
    if (st.isDirectory()) {
      fs.mkdirSync(dst, { recursive: true });
      for (const n of fs.readdirSync(src)) copy(path.join(src, n), path.join(dst, n));
    } else {
      mkdirp(path.dirname(dst)); fs.copyFileSync(src, dst);
    }
  };
  copy(tplDir, dir);
  res.json({ ok: true });
});

// ---------- Project init/build ----------
router.post("/init", (req, res) => {
  try {
    const { id, name, version } = req.body || {};
    const dir = path.join(WORK, id);
    if (exists(dir)) throw new Error("project exists");
    mkdirp(dir);
    write(path.join(dir, "package.json"), JSON.stringify({
      name: `@fabric/${id}`, version, private: false, type: "module",
      scripts: { build: "tsc -p tsconfig.json", test: "vitest run --reporter=dot" },
      devDependencies: { typescript: "^5.4.5", vitest: "^1.6.0", "@types/node": "^20.11.30" }
    }, null, 2));
    write(path.join(dir, "tsconfig.json"), JSON.stringify({ compilerOptions: { target:"ES2020", module:"ESNext", moduleResolution:"Bundler", outDir:"dist", rootDir:"src", strict:true, skipLibCheck:true }, include:["src","tests"] }, null, 2));
    write(path.join(dir, "src/index.ts"), `export const manifest = { id: "${id}", name: "${name}", version: "${version}" };\nexport default function() { console.log("hello from ${id}"); }`);
    write(path.join(dir, "tests/basic.test.ts"), `import { describe, it, expect } from 'vitest';\ndescribe('basic',()=>{ it('works',()=>{ expect(1+1).toBe(2) }) })`);
    write(path.join(dir, ".releaserc.json"), JSON.stringify({ branches:["main"], plugins:["@semantic-release/commit-analyzer","@semantic-release/release-notes-generator","@semantic-release/changelog","@semantic-release/npm","@semantic-release/github","@semantic-release/git"] }, null, 2));
    write(path.join(dir, ".github/workflows/release.yml"), `name: release\non: { push: { branches: [ main ] } }\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-node@v4\n        with: { node-version: 20 }\n      - run: npm ci\n      - run: npm test\n      - run: npm run build\n      - name: Cosign artifact\n        run: echo "$COSIGN_KEY" > cosign.key && cosign sign-blob --yes --key cosign.key dist/index.js > dist/index.js.sig\n        env:\n          COSIGN_KEY: ${{ secrets.COSIGN_KEY }}\n`);
    res.json({ ok: true, dir });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

router.post("/build", async (req, res) => {
  try {
    const { project } = req.body || {};
    const dir = path.join(WORK, project);
    const outdir = path.join(dir, "dist"); mkdirp(outdir);
    await esbuild.build({ entryPoints:[path.join(dir,"src/index.ts")], platform:"node", target:["es2020"], bundle:true, outfile:path.join(outdir,"index.js"), sourcemap:false, minify:true });
    const tgz = path.join(dir, `${project}.tgz`);
    await tar.create({ gzip:true, cwd: dir, file: tgz }, ["dist","README.md","package.json"]);
    res.json({ ok:true, tgz });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

router.post("/test", (req, res) => {
  const { project } = req.body || {};
  const dir = path.join(WORK, project);
  const child = spawn("npm", ["test", "--silent"], { cwd: dir, shell: true });
  let logs = ""; child.stdout.on("data", d=>logs+=d.toString()); child.stderr.on("data", d=>logs+=d.toString());
  child.on("close", code => res.json({ ok: code===0, code, logs }));
});

// ---------- Cosign + Verify ----------
router.post("/cosign", (req, res) => {
  try {
    const { project } = req.body || {};
    const dir = path.join(WORK, project);
    const tgz = path.join(dir, `${project}.tgz`);
    const keyRef = process.env.COSIGN_KEY || "";
    if (!keyRef) throw new Error("COSIGN_KEY not set");
    const { sigPath, sigB64 } = cosignSign(tgz, keyRef, process.env.COSIGN_PASSWORD);
    res.json({ ok:true, sigPath, sigB64 });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});
router.post("/verify", (req, res) => {
  try {
    const { project } = req.body || {};
    const dir = path.join(WORK, project);
    const tgz = path.join(dir, `${project}.tgz`);
    const sig = fs.readFileSync(tgz + ".sig", "utf8");
    const pub = process.env.COSIGN_PUB || "";
    if (!pub) throw new Error("COSIGN_PUB not set");
    const ok = cosignVerify(tgz, pub, sig);
    res.json({ ok });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

// ---------- Stage → Registry ----------
router.post("/stage", (req, res) => {
  try {
    const { project } = req.body || {};
    const dir = path.join(WORK, project);
    const pkg = JSON.parse(read(path.join(dir, "package.json")));
    const tgz = path.join(dir, `${project}.tgz`);
    const dstDir = path.join(STORE, "plugins", project, pkg.version);
    mkdirp(dstDir);
    fs.copyFileSync(tgz, path.join(dstDir, path.basename(tgz)));
    if (exists(tgz + ".sig")) fs.copyFileSync(tgz + ".sig", path.join(dstDir, path.basename(tgz)+".sig"));
    if (exists(path.join(dir,"README.md"))) fs.copyFileSync(path.join(dir,"README.md"), path.join(dstDir, "README.md"));
    // registry
    const entry = {
      id: project, name: pkg.name, version: pkg.version,
      readme: `plugins/${project}/${pkg.version}/README.md`,
      package: `plugins/${project}/${pkg.version}/${path.basename(tgz)}`,
      signature: exists(tgz+".sig") ? { algo:"cosign", sigUrl: `plugins/${project}/${pkg.version}/${path.basename(tgz)}.sig` } : undefined,
      categories: ["fabric-plugin"]
    };
    let reg = { updated_at: new Date().toISOString(), plugins: [] as any[] };
    if (exists(REG_PATH)) reg = JSON.parse(read(REG_PATH));
    const i = reg.plugins.findIndex((p:any)=>p.id===project && p.version===pkg.version);
    if (i>=0) reg.plugins[i]=entry; else reg.plugins.push(entry);
    reg.updated_at = new Date().toISOString();
    write(REG_PATH, JSON.stringify(reg, null, 2));
    res.json({ ok:true, entry });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

// ---------- Install to local Fabric before push ----------
router.post("/install", async (req, res) => {
  try {
    const { project } = req.body || {};
    const dir = path.join(WORK, project);
    const pkg = JSON.parse(read(path.join(dir,"package.json")));
    const source = `file://${path.join(STORE, "plugins", project, pkg.version, `${project}.tgz`)}`;
    const r = await fetch(`http://localhost:${process.env.PORT || 8080}/api/plugins/install`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ id: project, version: pkg.version, source, verifySignature: true, enable: true }) });
    if (!r.ok) throw new Error("install failed");
    res.json(await r.json().catch(()=>({ok:true})));
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

// ---------- Rollback / Unpublish ----------
router.post("/rollback", (req, res) => {
  try {
    const { project, version } = req.body || {};
    const dir = path.join(STORE, "plugins", project, version);
    rmrf(dir);
    let reg = exists(REG_PATH) ? JSON.parse(read(REG_PATH)) : { updated_at:null, plugins:[] };
    reg.plugins = reg.plugins.filter((p:any)=> !(p.id===project && p.version===version));
    reg.updated_at = new Date().toISOString();
    write(REG_PATH, JSON.stringify(reg, null, 2));
    res.json({ ok:true });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

// ---------- Git push & PR ----------
router.post("/push", async (req, res) => {
  try {
    const git = simpleGit(STORE);
    const branch = process.env.GIT_BRANCH || "devforge-publish";
    const remote = process.env.GIT_REMOTE || "origin";
    await git.add("."); await git.commit(req.body.message || "devforge: publish");
    try { await git.checkout(branch); } catch { await git.checkoutLocalBranch(branch); }
    await git.push(remote, branch);
    res.json({ ok:true, branch });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

router.post("/pr", async (req, res) => {
  try {
    const token = process.env.GITHUB_TOKEN; if (!token) throw new Error("GITHUB_TOKEN not set");
    const owner = process.env.GITHUB_OWNER; const repo = process.env.GITHUB_REPO; if (!owner || !repo) throw new Error("GITHUB_OWNER/REPO not set");
    const head = process.env.GIT_BRANCH || "devforge-publish"; const base = req.body.base || "main";
    const octo = new Octokit({ auth: token });
    const pr = await octo.pulls.create({ owner, repo, title: req.body.title || "DevForge publish", head, base });
    res.json({ ok:true, url: pr.data.html_url });
  } catch (e: any) { res.status(400).json({ error: String(e?.message||e) }); }
});

// ---------- Secrets (encrypted at rest) ----------
import CryptoJS from "crypto-js";
function enc(val: string){ if (!SECRET_KEY) throw new Error("DEVFORGE_SECRETS_KEY not set"); return CryptoJS.AES.encrypt(val, SECRET_KEY).toString(); }
function dec(val: string){ if (!SECRET_KEY) throw new Error("DEVFORGE_SECRETS_KEY not set"); try { return CryptoJS.AES.decrypt(val, SECRET_KEY).toString(CryptoJS.enc.Utf8); } catch { return ""; } }

router.post("/secrets/set", (req, res) => {
  const store = path.join(WORK, ".secrets.json");
  const obj = exists(store) ? JSON.parse(read(store)) : {};
  obj[req.body.key] = enc(req.body.value);
  write(store, JSON.stringify(obj, null, 2));
  res.json({ ok:true });
});
router.post("/secrets/list", (req, res) => {
  const store = path.join(WORK, ".secrets.json");
  const obj = exists(store) ? JSON.parse(read(store)) : {};
  res.json({ keys: Object.keys(obj) }); // don't return values
});
