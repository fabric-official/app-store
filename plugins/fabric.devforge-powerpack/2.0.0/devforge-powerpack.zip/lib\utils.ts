﻿export function greet(name: string){ return Hello, !; }
