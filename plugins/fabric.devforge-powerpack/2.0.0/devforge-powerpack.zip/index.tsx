﻿import React from "react";
export default function PluginRoot() {
  return (
    <div style={{ padding: 16 }}>
      <h1>DevForge Power Pack v2.0.0</h1>
      <p>Complete developer pipeline (Build/Test/Cosign/Verify/Stage/Install/Push/PR) with editor and templates.</p>
    </div>
  );
}
