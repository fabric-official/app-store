import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Bridge: Satellite (Iridium SBD) v1.0.0</h1><p>Satellite bridge for Iridium SBD via serial AT commands (RockBLOCK).</p></div>);
}