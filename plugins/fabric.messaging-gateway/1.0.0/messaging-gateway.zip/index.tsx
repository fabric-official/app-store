import React from "react";
export default function PluginRoot() {
  return (<div style={padding:16}><h1>Messaging Gateway (Matrix) v1.0.0</h1><p>Store-and-forward bridge to Matrix rooms/users. Maps Fabric threads to Matrix.</p></div>);
}